/* AtmosIQ map: Leaflet with a satellite basemap (Esri World Imagery, no key needed, dimmed for the dark UI)
   and a CARTO dark basemap as a switchable/automatic fallback.
   Marker colours come only from API data (/weather/map observed DWD values, /forecast/cities model output).
   If Leaflet or tiles cannot load (offline demo machine), the schematic SVG map is coloured instead. */
(() => {
  const BOUNDS = [[47.0, 5.4], [55.3, 15.6]];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  const RISK = {alert: '#e5484d', watch: '#f5a524', normal: '#2fb67c', unknown: '#8b93a7'};
  const RISK_LABEL = {alert: 'Alert', watch: 'Watch', normal: 'Normal', unknown: 'No data'};
  const RAMPS = {
    temp: [[-5, '#3b6fe0'], [5, '#58b7cf'], [15, '#79c9a4'], [25, '#f5c94c'], [35, '#e5484d']],
    rain: [[0, '#a9bcd8'], [5, '#58a0e4'], [10, '#2f6fd6'], [20, '#5a3fc0'], [40, '#8a1fa8']],
    wind: [[0, '#9fd4b8'], [20, '#e3d14f'], [40, '#f09a3e'], [60, '#e5484d']],
  };
  // mode -> how to read a value out of a city record
  const MODES = {
    risk: {label: 'Risk', title: 'Screening risk · latest observed day'},
    temp: {label: 'Temp', ramp: 'temp', unit: '°C', title: 'Observed daily max temperature', get: c => c.observed?.temp_max_c, fmt: v => `${Math.round(v)}°`},
    rain: {label: 'Rain', ramp: 'rain', unit: 'mm', title: 'Observed daily precipitation', get: c => c.observed?.rain_mm, fmt: v => `${v.toFixed(1)} mm`},
    wind: {label: 'Wind', ramp: 'wind', unit: 'km/h', title: 'Observed max hourly wind', get: c => c.observed?.wind_max_kmh, fmt: v => `${Math.round(v)} km/h`},
    forecast: {label: 'Forecast', ramp: 'temp', unit: '°C', title: 'Model forecast: next-day max temperature', get: c => c.forecast?.daily_high_temperature_c, fmt: v => `${Math.round(v)}°`},
  };

  function hex(h) { return [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); }
  function ramp(stops, v) {
    if (v <= stops[0][0]) return stops[0][1];
    for (let i = 1; i < stops.length; i++) {
      if (v <= stops[i][0]) {
        const [a, ca] = stops[i - 1], [b, cb] = stops[i], t = (v - a) / (b - a), x = hex(ca), y = hex(cb);
        return '#' + x.map((n, k) => Math.round(n + (y[k] - n) * t).toString(16).padStart(2, '0')).join('');
      }
    }
    return stops.at(-1)[1];
  }

  const fmtDay = d => { const t = new Date(d + 'T00:00:00Z'); return isNaN(t) ? String(d) : t.toLocaleDateString('en-GB', {day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC'}); };
  const state = {cities: [], mode: 'risk', selected: 'all', onSelect: () => {}, map: null, layer: {}, fallback: false, date: ''};

  function colorFor(city) {
    if (state.mode === 'risk') return RISK[city.risk?.level] || RISK.unknown;
    const v = MODES[state.mode].get(city);
    return Number.isFinite(v) ? ramp(RAMPS[MODES[state.mode].ramp], v) : RISK.unknown;
  }
  function valueText(city) {
    if (state.mode === 'risk') return RISK_LABEL[city.risk?.level] || 'No data';
    const m = MODES[state.mode], v = m.get(city);
    return Number.isFinite(v) ? m.fmt(v) : 'n/a';
  }

  function popupHtml(c) {
    const o = c.observed, f = c.forecast, st = c.station || {};
    const num = (v, u) => Number.isFinite(v) ? `${v}${u}` : 'n/a';
    const reasons = (c.risk?.reasons || []).map(r => `${r.level === 'alert' ? '⚠' : '•'} ${esc(r.type.replace('_', ' '))} ${r.value}${esc(r.unit)} (${r.level})`).join('<br>');
    return `<div class="atm-pop"><strong>${esc(c.name)}</strong><span class="atm-pill" style="background:${RISK[c.risk?.level] || RISK.unknown}">${RISK_LABEL[c.risk?.level] || 'No data'}</span>
      ${o ? `<table><tr><td>Max / min</td><td>${num(o.temp_max_c, '°')} / ${num(o.temp_min_c, '°')}</td></tr>
      <tr><td>Rain</td><td>${num(o.rain_mm, ' mm')}</td></tr><tr><td>Max wind</td><td>${num(o.wind_max_kmh, ' km/h')}</td></tr>
      <tr><td>Humidity</td><td>${num(o.humidity_mean_pct, '%')}</td></tr></table>` : '<p>No complete station record for this day.</p>'}
      ${reasons ? `<p class="atm-reasons">${reasons}</p>` : ''}
      ${f ? `<p class="atm-fc">Model forecast ${esc(state.forecastDate || '')}: ${num(f.daily_low_temperature_c, '°')} to ${num(f.daily_high_temperature_c, '°')}, RH ${num(Math.round(f.daily_low_humidity_pct), '')}–${num(Math.round(f.daily_high_humidity_pct), '%')}</p>` : ''}
      <small>Observed ${esc(state.date)} · DWD ${esc(st.name || 'station')}${st.distance_from_city_km != null ? ` (${st.distance_from_city_km} km from centre)` : ''}</small></div>`;
  }

  function buildLegend() {
    const el = document.getElementById('map-legend');
    if (!el) return;
    const noData = `<span><i style="background:${RISK.unknown}"></i>No data</span>`;
    if (!state.cities.length) {
      el.innerHTML = '<span>No map data loaded</span>';
    } else if (state.mode === 'risk') {
      el.innerHTML = ['alert', 'watch', 'normal', 'unknown'].map(k => `<span><i style="background:${RISK[k]}"></i>${RISK_LABEL[k]}</span>`).join('');
    } else {
      const m = MODES[state.mode], stops = RAMPS[m.ramp];
      el.innerHTML = `<span class="legend-grad" style="background:linear-gradient(90deg,${stops.map(s => s[1]).join(',')})"></span><span>${stops[0][0]} → ${stops.at(-1)[0]}+ ${m.unit}</span>${noData}`;
    }
    const t = document.getElementById('map-mode-title');
    if (t) {
      const when = state.mode === 'forecast' ? (state.forecastDate ? `for ${fmtDay(state.forecastDate)}` : '') : (state.date ? `observed ${fmtDay(state.date)}` : '');
      t.textContent = state.cities.length ? `${MODES[state.mode].title}${when ? ' · ' + when : ''}` : `${MODES[state.mode].title} · no data`;
    }
  }

  function refresh() {
    buildLegend();
    state.cities.forEach(c => {
      const color = colorFor(c), sel = state.selected === c.name;
      if (state.fallback) {
        const g = document.querySelector(`.city-marker[data-city="${CSS.escape(c.name)}"]`);
        if (g) {
          const dot = g.querySelector('circle:not(.marker-halo)');
          dot.setAttribute('r', '8'); dot.style.fill = color; dot.style.stroke = '#fff';
          const label = g.querySelector('text'); if (label) label.textContent = state.mode === 'risk' ? c.name : `${c.name} ${valueText(c)}`;
        }
        return;
      }
      const mk = state.layer[c.name];
      if (!mk) return;
      mk.setStyle({fillColor: color, color: sel ? '#ffffff' : '#0b1220', weight: sel ? 4 : 2.5, radius: sel ? 17 : 13});
      mk.setTooltipContent(`<b>${esc(c.name)}</b> ${esc(valueText(c))}`);
      mk.getPopup()?.setContent(popupHtml(c));
      if (sel) mk.bringToFront();
    });
  }

  function showFallback(reason) {
    state.fallback = true;
    document.getElementById('leaflet-map')?.setAttribute('hidden', '');
    const svg = document.getElementById('germany-map');
    svg?.removeAttribute('hidden');
    const foot = document.getElementById('map-foot');
    if (foot) foot.textContent = `${reason} Showing the offline schematic map; marker colours still use the same data.`;
    document.getElementById('map-tile-warning')?.setAttribute('hidden', '');
    refresh();
    document.dispatchEvent(new Event('atmos-basemap'));
  }

  function init(opts) {
    Object.assign(state, {onSelect: opts.onSelect || state.onSelect});
    const el = document.getElementById('leaflet-map');
    if (!window.L) { showFallback('Leaflet could not be loaded (no internet?).'); return; }
    const L = window.L;
    state.map = L.map(el, {zoomSnap: 0.25, minZoom: 5, maxBounds: [[45.5, 3.5], [57, 17.5]], scrollWheelZoom: false});
    state.map.fitBounds(BOUNDS);
    const mkTiles = (url, opts) => {
      let errors = 0;
      const t = L.tileLayer(url, opts);
      t.on('tileerror', () => { if (++errors === 6) t.fire('tilesfailed'); });
      return t;
    };
    const satellite = mkTiles('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {maxZoom: 10, className: 'atm-sat', attribution: 'Imagery © Esri, Maxar, Earthstar Geographics &amp; the GIS User Community'});
    const dark = mkTiles('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
      {maxZoom: 12, subdomains: 'abcd', attribution: '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> contributors © <a href="https://carto.com/attributions" target="_blank" rel="noreferrer">CARTO</a>'});
    state.basemap = 'Satellite imagery (Esri World Imagery, dimmed)';
    satellite.addTo(state.map);
    const ctl = L.control.layers({'Satellite': satellite, 'Dark map': dark}, null, {position: 'topright', collapsed: false}).addTo(state.map);
    state.map.on('baselayerchange', e => { state.basemap = e.name === 'Satellite' ? 'Satellite imagery (Esri World Imagery, dimmed)' : 'Dark basemap (CARTO / OpenStreetMap)'; document.dispatchEvent(new Event('atmos-basemap')); });
    // Satellite tiles fail -> dark basemap. Dark tiles fail too -> offline schematic map (markers keep the same data).
    satellite.on('tilesfailed', () => {
      if (state.fallback) return;
      if (state.map.hasLayer(satellite)) { state.map.removeLayer(satellite); dark.addTo(state.map); }
      ctl.removeLayer(satellite);
      state.basemap = 'Dark basemap (CARTO / OpenStreetMap) - satellite tiles unavailable';
      document.dispatchEvent(new Event('atmos-basemap'));
    });
    dark.on('tilesfailed', () => { if (state.map.hasLayer(dark) && !state.fallback) showFallback('Map tiles could not be loaded.'); });
    // Re-fit when the container is resized (responsive layouts, fullscreen).
    if (window.ResizeObserver) new ResizeObserver(() => { state.map.invalidateSize(); state.map.fitBounds(BOUNDS); }).observe(el);
  }

  function setData(data, forecast) {
    state.date = data.date;
    state.forecastDate = forecast?.prediction_date || '';
    state.cities = data.cities.map(c => ({...c, forecast: forecast?.cities?.[c.name] || null}));
    if (!state.fallback && state.map && !Object.keys(state.layer).length) {
      const L = window.L;
      state.cities.forEach(c => {
        const mk = L.circleMarker([c.latitude, c.longitude], {radius: 13, weight: 2.5, color: '#0b1220', fillOpacity: .95})
          .bindTooltip('', {permanent: true, direction: 'right', offset: [10, 0], className: 'atm-label'})
          .bindPopup('', {maxWidth: 260}).addTo(state.map);
        mk.on('click', () => state.onSelect(c.name));
        state.layer[c.name] = mk;
      });
    }
    refresh();
  }

  window.AtmosMap = {
    init, setData,
    setMode(mode) { if (MODES[mode]) { state.mode = mode; refresh(); } },
    select(name) {
      state.selected = name; refresh();
      const mk = state.layer[name];
      if (state.fallback) {
        const c = state.cities.find(x => x.name === name), foot = document.getElementById('map-foot'), o = c?.observed;
        if (foot && c) foot.textContent = `${c.name} · ${RISK_LABEL[c.risk?.level] || 'No data'}` + (o ? ` · max ${o.temp_max_c ?? 'n/a'}° / min ${o.temp_min_c ?? 'n/a'}°, rain ${o.rain_mm ?? 'n/a'} mm, wind ${o.wind_max_kmh ?? 'n/a'} km/h` : ' · no complete station record') + ` · observed ${fmtDay(state.date)}`;
      } else if (mk && state.map) { state.map.panTo(mk.getLatLng(), {animate: true}); mk.openPopup(); }
      else if (name === 'all' && state.map) { state.map.closePopup(); state.map.fitBounds(BOUNDS); }
    },
    hasForecast: () => state.cities.some(c => c.forecast),
    isFallback: () => state.fallback,
    basemap: () => state.basemap || '',
  };
})();
