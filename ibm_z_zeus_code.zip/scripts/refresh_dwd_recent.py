"""Refresh the DWD provisional 2026 station observations in the bundled archive.

Run from the project root with pandas installed. Historical 2024–2025 records
remain untouched; current DWD recent/akt files replace the 2026+ portion.
"""
from __future__ import annotations

import io
import json
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CSV = ROOT / "data" / "dwd_station_observations_2024_2026.csv"
META = ROOT / "data" / "dwd_station_observations.metadata.json"
BASE = "https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly"
STATIONS = {
    "Hamburg": {"TU": "01975", "RR": "01975", "FF": "01975"},
    "Berlin": {"TU": "00433", "RR": "17473", "FF": "00433"},
    "Hannover": {"TU": "02014", "RR": "02011", "FF": "02014"},
    "Cologne": {"TU": "02667", "RR": "02667", "FF": "02667"},
    "Leipzig": {"TU": "02928", "RR": "02928", "FF": "02928"},
    "Dresden": {"TU": "01050", "RR": "01050", "FF": "01048"},
    "Frankfurt": {"TU": "01424", "RR": "01424", "FF": "07341"},
    "Stuttgart": {"TU": "04928", "RR": "04928", "FF": "04928"},
    "Munich": {"TU": "03379", "RR": "03379", "FF": "03379"},
}
PRODUCT = {"TU": ("air_temperature", {"TT_TU": "temperature_2m_c", "RF_TU": "relative_humidity_pct"}, "QN_9"),
           "RR": ("precipitation", {"R1": "precipitation_mm"}, "QN_8"),
           "FF": ("wind", {"F": "wind_speed_ms", "D": "wind_direction_deg"}, "QN_3")}


def get_recent(code: str, station_id: str) -> pd.DataFrame:
    product, fields, qn = PRODUCT[code]
    url = f"{BASE}/{product}/recent/stundenwerte_{code}_{station_id}_akt.zip"
    request = urllib.request.Request(url, headers={"User-Agent": "ClimateGuard-Datathon/1.0"})
    with urllib.request.urlopen(request, timeout=90) as response:
        payload = response.read()
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        member = next(name for name in archive.namelist() if name.startswith("produkt_") and name.endswith(".txt"))
        frame = pd.read_csv(io.BytesIO(archive.read(member)), sep=";", dtype=str, low_memory=False)
    frame.columns = [x.strip() for x in frame.columns]
    frame["timestamp_utc"] = pd.to_datetime(frame["MESS_DATUM"].str.strip(), format="%Y%m%d%H", errors="coerce")
    frame = frame.loc[frame.timestamp_utc >= pd.Timestamp("2026-01-01")].copy()
    for column in [*fields, qn]:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
        frame.loc[frame[column] <= -900, column] = float("nan")
    return frame[["timestamp_utc", *fields, qn]].rename(columns={**fields, qn: f"quality_{code.lower()}"})


def main() -> None:
    if not CSV.exists() or not META.exists():
        raise SystemExit("Bundled DWD archive is missing; run the initial project setup first.")
    existing = pd.read_csv(CSV, parse_dates=["timestamp_utc"])
    historical = existing.loc[existing.timestamp_utc < pd.Timestamp("2026-01-01")].copy()
    fresh_city_frames = []
    for city, assignment in STATIONS.items():
        merged = None
        for code, station_id in assignment.items():
            product = get_recent(code, station_id)
            if merged is None:
                merged = product
            else:
                merged = merged.merge(product, on="timestamp_utc", how="outer", suffixes=("", f"_{code.lower()}"))
        old_city = existing.loc[existing.city == city].sort_values("timestamp_utc")
        station_columns = [c for c in old_city.columns if c.startswith("station_")]
        for col in station_columns:
            merged[col] = old_city[col].iloc[0]
        merged["city"] = city
        merged["wind_speed_kmh"] = merged["wind_speed_ms"] * 3.6
        for col in old_city.columns:
            if col not in merged.columns:
                merged[col] = "recent, quality control pending" if col.startswith("record_status") else pd.NA
        # Ensure canonical field order and mark this source period as provisional.
        merged["record_status"] = "recent, quality control pending"
        for col in ("record_status_rr", "record_status_ff"):
            if col in merged:
                merged[col] = "recent, quality control pending"
        fresh_city_frames.append(merged[old_city.columns])
    result = pd.concat([historical, *fresh_city_frames], ignore_index=True).sort_values(["city", "timestamp_utc"])
    result["timestamp_utc"] = pd.to_datetime(result.timestamp_utc).dt.strftime("%Y-%m-%dT%H:%M:%S")
    result.to_csv(CSV, index=False)
    meta = json.loads(META.read_text(encoding="utf-8"))
    meta["period"]["end"] = str(result.timestamp_utc.max()[:10])
    meta["downloaded_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    meta["recent_quality_note"] = "Recent/akt files refreshed by scripts/refresh_dwd_recent.py; quality control may still change these values."
    meta["coverage"] = {}
    data = result.assign(_date=result.timestamp_utc.str[:10])
    for city, group in data.groupby("city"):
        meta["coverage"][city] = {"rows": int(len(group)), "first_timestamp": group.timestamp_utc.min(),
            "last_timestamp": group.timestamp_utc.max(), "nonmissing_hours": {
                col: int(group[col].notna().sum()) for col in
                ("temperature_2m_c", "relative_humidity_pct", "precipitation_mm", "wind_speed_kmh")}}
    META.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Refreshed DWD records through {meta['period']['end']} for {len(STATIONS)} cities.")


if __name__ == "__main__":
    main()
