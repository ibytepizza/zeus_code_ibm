"""Build the bundled DWD city-station archive from DWD CDC station ZIP files.

The ZIP input folder is not distributed; source URLs, station choices and license
attribution are recorded in data/dwd_station_observations.metadata.json.
"""
from __future__ import annotations

import argparse
import io
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CITY_VARIABLE_STATIONS = {
    "Hamburg": {"TU": "01975", "RR": "01975", "FF": "01975"},
    "Berlin": {"TU": "00433", "RR": "17473", "FF": "00433"},
    "Hannover": {"TU": "02014", "RR": "02011", "FF": "02014"},
    "Cologne": {"TU": "02667", "RR": "02667", "FF": "02667"},
    "Leipzig": {"TU": "02928", "RR": "02928", "FF": "02928"},
    "Dresden": {"TU": "01050", "RR": "01050", "FF": "01048"},
    "Frankfurt": {"TU": "01424", "RR": "01424", "FF": "07341"},
    "Stuttgart": {"TU": "04928", "RR": "04928", "FF": "04928"},
    "Munich": {"TU": "03379", "RR": "03379", "FF": "03379"},
}
CITY_COORDS = {
    "Hamburg": (53.55, 10.0), "Berlin": (52.52, 13.40), "Hannover": (52.38, 9.73),
    "Cologne": (50.94, 6.96), "Leipzig": (51.34, 12.37), "Dresden": (51.05, 13.74),
    "Frankfurt": (50.11, 8.68), "Stuttgart": (48.78, 9.18), "Munich": (48.14, 11.58),
}
PRODUCT_META = {
    "TU": ("air_temperature", "TU_Stundenwerte_Beschreibung_Stationen.txt"),
    "RR": ("precipitation", "RR_Stations.txt"),
    "FF": ("wind", "FF_Stations.txt"),
}
FIELDS = {
    "TU": {"TT_TU": "temperature_2m_c", "RF_TU": "relative_humidity_pct"},
    "RR": {"R1": "precipitation_mm"},
    "FF": {"F": "wind_speed_ms", "D": "wind_direction_deg"},
}
QUALITY_COL = {"TU": "QN_9", "RR": "QN_8", "FF": "QN_3"}


def station_catalog(raw_dir: Path, code: str) -> dict[str, dict]:
    _, filename = PRODUCT_META[code]
    path = raw_dir / filename
    catalog = {}
    for line in path.read_text(encoding="latin1").splitlines():
        parts = line.split()
        if len(parts) < 7 or not parts[0].isdigit():
            continue
        try:
            catalog[parts[0].zfill(5)] = {
                "elevation_m": float(parts[3]), "latitude": float(parts[4]),
                "longitude": float(parts[5]), "name": " ".join(parts[6:]),
            }
        except ValueError:
            continue
    return catalog


def read_product(raw_dir: Path, code: str, station_id: str) -> pd.DataFrame:
    product_dir, _ = PRODUCT_META[code]
    frames = []
    for era, date_filter in (
        ("historical", lambda d: (d >= pd.Timestamp("2024-01-01")) & (d < pd.Timestamp("2026-01-01"))),
        ("recent", lambda d: d >= pd.Timestamp("2026-01-01")),
    ):
        pattern = (f"stundenwerte_{code}_{station_id}_*_hist.zip" if era == "historical"
                   else f"stundenwerte_{code}_{station_id}_akt.zip")
        paths = list(raw_dir.glob(pattern))
        if len(paths) != 1:
            raise FileNotFoundError(f"Expected one {era} archive for {code}/{station_id}; found {paths}")
        with zipfile.ZipFile(paths[0]) as archive:
            member = next(n for n in archive.namelist() if n.startswith("produkt_") and n.endswith(".txt"))
            data = pd.read_csv(io.BytesIO(archive.read(member)), sep=";", dtype=str, low_memory=False)
        data.columns = [c.strip() for c in data.columns]
        data["timestamp_utc"] = pd.to_datetime(data["MESS_DATUM"].str.strip(), format="%Y%m%d%H", errors="coerce")
        data = data.loc[date_filter(data["timestamp_utc"])].copy()
        selected = list(FIELDS[code])
        for col in selected + [QUALITY_COL[code]]:
            data[col] = pd.to_numeric(data[col], errors="coerce")
            data.loc[data[col] <= -900, col] = float("nan")
        rename = dict(FIELDS[code])
        rename[QUALITY_COL[code]] = f"quality_{code.lower()}"
        data = data[["timestamp_utc", *selected, QUALITY_COL[code]]].rename(columns=rename)
        data["record_status"] = "quality-checked historical" if era == "historical" else "recent, quality control pending"
        frames.append(data)
    result = pd.concat(frames, ignore_index=True).drop_duplicates("timestamp_utc", keep="last")
    return result


def build(raw_dir: Path, output: Path, metadata_path: Path) -> dict:
    catalogs = {code: station_catalog(raw_dir, code) for code in PRODUCT_META}
    rows, station_metadata = [], {}
    for city, assignment in CITY_VARIABLE_STATIONS.items():
        combined = None
        city_station_meta = {}
        for code, station_id in assignment.items():
            catalog = catalogs[code]
            if station_id not in catalog:
                raise ValueError(f"Station {station_id} missing from {code} station metadata")
            info = catalog[station_id]
            station_name = info["name"]
            from math import asin, cos, radians, sin, sqrt
            city_lat, city_lon = CITY_COORDS[city]
            lat1, lon1, lat2, lon2 = map(radians, (city_lat, city_lon, info["latitude"], info["longitude"]))
            a = sin((lat2 - lat1) / 2) ** 2 + cos(lat1) * cos(lat2) * sin((lon2 - lon1) / 2) ** 2
            station_distance = 6371 * 2 * asin(sqrt(a))
            parsed = read_product(raw_dir, code, station_id)
            if combined is None:
                combined = parsed
            else:
                shared_status = "record_status"
                parsed = parsed.rename(columns={shared_status: f"record_status_{code.lower()}"})
                combined = combined.merge(parsed, on="timestamp_utc", how="outer")
            city_station_meta[code] = {
                "station_id": station_id, "station_name": station_name,
                **info, "distance_from_city_km": round(station_distance, 1),
                "source_category": PRODUCT_META[code][0],
            }
            combined[f"station_{code.lower()}_id"] = station_id
            combined[f"station_{code.lower()}_name"] = station_name
            combined[f"station_{code.lower()}_latitude"] = info["latitude"]
            combined[f"station_{code.lower()}_longitude"] = info["longitude"]
        combined["city"] = city
        if "record_status" in combined.columns:
            combined["record_status"] = combined["record_status"].fillna("no observation")
        for code in ("RR", "FF"):
            col = f"record_status_{code.lower()}"
            if col in combined:
                combined[col] = combined[col].fillna("no observation")
        combined["wind_speed_kmh"] = combined["wind_speed_ms"] * 3.6
        rows.append(combined)
        station_metadata[city] = city_station_meta
    result = pd.concat(rows, ignore_index=True).sort_values(["city", "timestamp_utc"])
    result["timestamp_utc"] = result["timestamp_utc"].dt.strftime("%Y-%m-%dT%H:%M:%S")
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    variables = ["temperature_2m_c", "relative_humidity_pct", "precipitation_mm", "wind_speed_kmh"]
    coverage = {}
    for city, group in result.groupby("city"):
        coverage[city] = {"rows": int(len(group)), "first_timestamp": group.timestamp_utc.min(),
                          "last_timestamp": group.timestamp_utc.max(),
                          "nonmissing_hours": {col: int(group[col].notna().sum()) for col in variables}}
    meta = {
        "source": "Deutscher Wetterdienst (DWD), Climate Data Center (CDC) OpenData",
        "source_url": "https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/",
        "license": "Creative Commons Attribution 4.0 International (CC BY 4.0)",
        "attribution": "Source: Deutscher Wetterdienst (DWD), Climate Data Center (CDC); CC BY 4.0.",
        "data_kind": "Hourly station measurements; historical records are quality checked; recent records have quality control pending.",
        "period": {"start": "2024-01-01", "end": str(result.timestamp_utc.max()[:10])},
        "timezone": "UTC as reported in the DWD hourly observation timestamp field",
        "downloaded_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "recent_quality_note": "For dates from 2026-01-01 onward, the DWD recent/akt files were used. DWD notes quality control may still change these values.",
        "historical_quality_note": "For dates through 2025-12-31, the DWD historical/hist archives were used; DWD describes these as quality checked and versioned.",
        "variables": variables + ["wind_direction_deg"], "coverage": coverage, "city_stations": station_metadata,
        "dwd_docs": {code: f"https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/{product}/" for code, (product, _) in PRODUCT_META.items()},
    }
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    return meta


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=Path, required=True, help="Directory holding DWD station ZIPs and station lists")
    parser.add_argument("--output", type=Path, default=ROOT / "data/dwd_station_observations_2024_2026.csv")
    parser.add_argument("--metadata", type=Path, default=ROOT / "data/dwd_station_observations.metadata.json")
    args = parser.parse_args()
    meta = build(args.raw_dir, args.output, args.metadata)
    print(json.dumps({"output": str(args.output), "period": meta["period"], "coverage": meta["coverage"]}, indent=2))


if __name__ == "__main__":
    main()
