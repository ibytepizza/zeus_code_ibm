"""Evaluate a pre-cutoff ECMWF-trained model against DWD station observations.

This is an out-of-time cross-source check: all model fitting and model selection
use only ECMWF targets before --start; DWD station values after that date are
used only as evaluation labels. It is a diagnostic, not an official forecast skill
claim because the input and target sources differ.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import train_reanalysis as training  # noqa: E402
from climate_guard.data import TARGETS  # noqa: E402
from climate_guard.modelling import make_estimator, _selected_columns, TOLERANCES  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start', default='2026-03-28', help='First station-evaluation date (YYYY-MM-DD)')
    parser.add_argument('--min-hourly-coverage', type=int, default=18)
    args = parser.parse_args()
    cutoff = pd.Timestamp(args.start)
    frames = training.load_city_frames(ROOT / 'data/reanalysis_hourly_2024_2026.csv',
                                       ROOT / 'data/reanalysis_hourly_2024_2026.metadata.json')
    station = pd.read_csv(ROOT / 'data/dwd_station_observations_2024_2026.csv', parse_dates=['timestamp_utc'])
    station['date'] = station.timestamp_utc.dt.normalize()
    min_hours = args.min_hourly_coverage
    daily = station.groupby(['city', 'date']).agg(
        n_temp=('temperature_2m_c', 'count'), low_temp=('temperature_2m_c', 'min'), high_temp=('temperature_2m_c', 'max'),
        n_humidity=('relative_humidity_pct', 'count'), low_humidity=('relative_humidity_pct', 'min'), high_humidity=('relative_humidity_pct', 'max')).reset_index()
    city_map = {
        'daily_low_temperature_c': ('low_temp', 'n_temp'), 'daily_high_temperature_c': ('high_temp', 'n_temp'),
        'daily_low_humidity_pct': ('low_humidity', 'n_humidity'), 'daily_high_humidity_pct': ('high_humidity', 'n_humidity')}
    results, predictions = {}, []
    for target in TARGETS:
        examples = training.build_examples(frames, target)
        columns = [c for c in examples.columns if c not in (target, 'location')]
        fit = examples[examples.index < cutoff]
        test = examples[examples.index >= cutoff]
        if fit.empty or test.empty:
            raise ValueError(f'No training or test examples for {target} at cutoff {cutoff.date()}')
        selected, cv = training.select_by_date(fit, columns, target)
        chosen_columns = _selected_columns(selected, columns)
        model = make_estimator(selected, target).fit(fit[chosen_columns], fit[target])
        forecast = model.predict(test[chosen_columns])
        label_col, count_col = city_map[target]
        out = test[['location']].copy()
        out['date'] = test.index
        out['target'] = target
        out['prediction_ecmwf_model'] = forecast
        out = out.merge(daily[['city', 'date', label_col, count_col]], left_on=['location', 'date'], right_on=['city', 'date'], how='inner')
        out = out[out[count_col] >= min_hours].copy()
        out['station_observation'] = out[label_col]
        out['error'] = out.prediction_ecmwf_model - out.station_observation
        tolerance = TOLERANCES[target]
        stats = {'selected_model': selected, 'evaluation_start': str(cutoff.date()),
                 'evaluation_end': str(out.date.max().date()) if len(out) else None,
                 'matched_city_days': int(len(out)), 'cities_covered': sorted(out.location.unique().tolist()),
                 'minimum_station_hours_per_day': min_hours, 'tolerance': tolerance,
                 'station_mae': round(float(out.error.abs().mean()), 3) if len(out) else None,
                 'station_rmse': round(float(np.sqrt(np.mean(out.error**2))), 3) if len(out) else None,
                 'bias_prediction_minus_station': round(float(out.error.mean()), 3) if len(out) else None,
                 'within_tolerance_pct': round(float(100*(out.error.abs() <= tolerance).mean()), 2) if len(out) else None,
                 'warning': 'Diagnostic cross-source evaluation. Model uses ECMWF gridded inputs and was fitted to ECMWF targets; scores compare predictions with DWD stations, not a station-trained model.'}
        results[target] = stats
        out[['date', 'location', 'target', 'prediction_ecmwf_model', 'station_observation', count_col, 'error']].to_csv(ROOT / 'reports' / f'dwd_model_validation_{target}.csv', index=False)
        predictions.append(out)
    output = {'source': 'DWD CDC station observations versus ECMWF-trained model predictions',
              'cutoff': str(cutoff.date()), 'results': results}
    (ROOT / 'reports' / 'dwd_model_validation.json').write_text(json.dumps(output, indent=2), encoding='utf-8')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
