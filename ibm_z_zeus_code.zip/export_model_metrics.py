"""Export actual V5 2024 holdout scores and individual predictions as CSV.

Run: python export_model_metrics.py
No re-training; reads trusted evaluations saved when `train_all` was run.
Accuracy is a tolerance-defined "hit rate", NEVER classification accuracy.
"""
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import r2_score

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from climate_guard.data import TARGETS
from climate_guard.modelling import MODEL_FILES


def build_report(data_path=None, artifacts_dir=ROOT/'artifacts'):
    artifacts_dir = Path(artifacts_dir)
    rows, details = [], []
    for target in TARGETS:
        meta_file = artifacts_dir/MODEL_FILES[target].replace('.joblib', '.json')
        detail_file = artifacts_dir/f'holdout_{target}.csv'
        if not meta_file.exists() or not detail_file.exists():
            raise FileNotFoundError(f'Missing V5 evaluation artifact for {target}; run train_all')
        meta = json.loads(meta_file.read_text())
        holdout = pd.read_csv(detail_file)
        if meta['target'] != target or set(holdout.target) != {target}:
            raise ValueError(f'Wrong target in evaluation artifact {target}')
        if len(holdout) != meta['n_holdout_days']:
            raise ValueError(f'{target}: saved n_holdout_days differs from recalculated CSV count')
        y = holdout.actual.to_numpy(dtype=float)
        pred = holdout.predicted.to_numpy(dtype=float)
        base = holdout.baseline_predicted.to_numpy(dtype=float)
        tol = meta['validation']['tolerance']
        relaxed = meta['validation']['relaxed_tolerance']
        if abs(np.mean(np.abs(y-pred)) - meta['validation']['mae'])>.01:
            raise ValueError(f'Corrupt holdout predictions for {target}')
        if not (np.isfinite(y).all() and np.isfinite(pred).all() and np.isfinite(base).all()):
            raise ValueError(f'Nonfinite holdout data for {target}')
        rows.append({
            'target':target,
            'algorithm_selected':meta['selected_model'],
            'unit':'°C' if target.endswith('_temperature_c') else 'RH percentage points',
            'strict_tolerance':tol,
            'strict_tolerance_accuracy_pct':round(100*np.mean(np.abs(y-pred)<=tol),2),
            'relaxed_tolerance':relaxed,
            'relaxed_tolerance_accuracy_pct':round(100*np.mean(np.abs(y-pred)<=relaxed),2),
            'mae':round(float(np.mean(np.abs(y-pred))),4),
            'rmse':round(float(np.sqrt(np.mean((y-pred)**2))),4),
            'r2':round(float(r2_score(y,pred)),4),
            'median_absolute_error':round(float(np.median(np.abs(y-pred))),4),
            'p90_absolute_error':round(float(np.percentile(np.abs(y-pred),90)),4),
            'max_absolute_error':round(float(np.max(np.abs(y-pred))),4),
            'mean_bias_prediction_minus_actual':round(float(np.mean(pred-y)),4),
            'baseline_strict_accuracy_pct':round(100*np.mean(np.abs(y-base)<=tol),2),
            'baseline_mae':round(float(np.mean(np.abs(y-base))),4),
            'beats_baseline_mae':bool(np.mean(np.abs(y-pred))<np.mean(np.abs(y-base))),
            'beats_baseline_strict_accuracy':bool(np.mean(np.abs(y-pred)<=tol)>np.mean(np.abs(y-base)<=tol)),
            'n_labeled_days':meta['n_labeled_days'],
            'n_training_days':meta['n_training_days'],
            'n_holdout_days':meta['n_holdout_days'],
            'train_start':meta['training_dates'][0],
            'train_end':str(pd.Timestamp(meta['holdout_dates'][0])-pd.Timedelta(days=1))[:10],
            'holdout_start':meta['holdout_dates'][0],
            'holdout_end':meta['holdout_dates'][1],
            'selection_method':'rolling 2-fold chronology inside first 80%; last 20% reused from prior development cycles',
            'notes':'Exploratory retrospective test; previously examined in V3/V4; not a pristine final test; one 2024 source-year only',
        })
        details.append(holdout)
    return rows,pd.concat(details,ignore_index=True)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifacts',type=Path,default=ROOT/'artifacts')
    parser.add_argument('--output',type=Path,default=ROOT/'reports')
    parser.add_argument('--data',type=Path,default=ROOT/'data/meteostat_2024.csv', help='Reserved for project compatibility; stored model holdouts are used')
    args=parser.parse_args(argv)
    rows,detail=build_report(args.data,args.artifacts)
    args.output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output/'model_metrics.csv',index=False,encoding='utf-8-sig')
    detail.to_csv(args.output/'holdout_predictions.csv',index=False,encoding='utf-8-sig')
    for row in rows:
        print(row['target'],row['algorithm_selected'],f"strict={row['strict_tolerance_accuracy_pct']}%",
              f"relaxed={row['relaxed_tolerance_accuracy_pct']}%",f"MAE={row['mae']}")
    print('Reports saved to',args.output)

if __name__=='__main__':
    main()
