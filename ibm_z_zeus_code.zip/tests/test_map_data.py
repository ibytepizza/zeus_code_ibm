"""Tests for the dashboard map / alerts logic (pandas only) and the new API routes."""
import json
from pathlib import Path

import pandas as pd
import pytest

from climate_guard.map_data import build_alerts, build_city_conditions

BASE = Path(__file__).parents[1]
POINTS = [('Berlin', 52.52, 13.40), ('Munich', 48.14, 11.58)]


def _frame(rows):
    """rows: {(city, date): dict(temp=[24 values] or scalar, rain=..., wind=...)}"""
    out = []
    for (city, date), v in rows.items():
        for h in range(24):
            out.append({'city': city, 'date': date, 'timestamp_utc': pd.Timestamp(f'{date}T{h:02d}:00:00'),
                        'temperature_2m_c': v.get('temp', 10) if not isinstance(v.get('temp'), list) else v['temp'][h],
                        'relative_humidity_pct': 70.0, 'precipitation_mm': v.get('rain', 0.0) / 24,
                        'wind_speed_kmh': v.get('wind', 10.0)})
    return pd.DataFrame(out)


def test_risk_levels_and_alerts():
    hot = [20.0] * 12 + [31.0] + [20.0] * 11
    f = _frame({('Berlin', '2026-07-01'): {'temp': hot, 'rain': 4.0},
                ('Munich', '2026-07-01'): {'temp': 12, 'rain': 12.0, 'wind': 61.0}})
    m = build_city_conditions(f, {'city_stations': {}}, POINTS)
    by = {c['name']: c for c in m['cities']}
    assert m['date'] == '2026-07-01'
    assert by['Berlin']['risk']['level'] == 'alert' and by['Berlin']['risk']['reasons'][0]['type'] == 'heat'
    assert by['Munich']['risk']['level'] == 'alert'   # wind 61 >= 60
    assert {r['type'] for r in by['Munich']['risk']['reasons']} == {'heavy_rain', 'strong_wind'}
    alerts = build_alerts(f, 14, {'Berlin': (52.52, 13.4)})['alerts']
    assert alerts[0]['severity'] >= alerts[-1]['severity'] and alerts[0]['date'] == '2026-07-01'
    assert any(a['city'] == 'Berlin' and a['latitude'] == 52.52 for a in alerts)


def test_frost_watch_and_incomplete_day_is_not_scored():
    f = _frame({('Berlin', '2026-01-02'): {'temp': 2.0}, ('Munich', '2026-01-02'): {'temp': -1.0}})
    f.loc[(f.city == 'Munich') & (f.timestamp_utc.dt.hour >= 6), 'temperature_2m_c'] = float('nan')  # only 6 hours
    by = {c['name']: c for c in build_city_conditions(f, {}, POINTS)['cities']}
    assert by['Berlin']['risk']['level'] == 'watch'            # min 2 °C <= 3 °C watch level
    assert by['Munich']['observed']['temp_min_c'] is None      # too few hours: not invented


def test_unknown_date_rejected():
    f = _frame({('Berlin', '2026-01-02'): {}})
    with pytest.raises(ValueError):
        build_city_conditions(f, {}, POINTS, '2030-01-01')


def test_real_dwd_archive_has_all_cities():
    csv = BASE / 'data' / 'dwd_station_observations_2024_2026.csv'
    if not csv.exists():
        pytest.skip('DWD archive not bundled')
    f = pd.read_csv(csv, parse_dates=['timestamp_utc'])
    f['date'] = f['timestamp_utc'].dt.strftime('%Y-%m-%d')
    meta = json.loads((BASE / 'data' / 'dwd_station_observations.metadata.json').read_text(encoding='utf-8'))
    pts = [(n, 50.0, 10.0) for n in sorted(f['city'].unique())]
    m = build_city_conditions(f, meta, pts)
    assert len(m['cities']) == 9 and m['summary']['unknown'] == 0
    assert all(c['station']['name'] for c in m['cities'])


def test_api_routes():
    from fastapi.testclient import TestClient
    from climate_guard.api import app
    client = TestClient(app)
    r = client.get('/api/v1/weather/map')
    assert r.status_code == 200 and len(r.json()['cities']) == 9
    assert client.get('/api/v1/weather/map?date=1999-01-01').status_code == 404
    assert client.get('/api/v1/weather/alerts?days=90').status_code == 200
    r = client.get('/api/v1/forecast/cities')
    assert r.status_code == 200 and set(r.json()['cities']['Berlin']) == {
        'daily_low_temperature_c', 'daily_high_temperature_c', 'daily_low_humidity_pct', 'daily_high_humidity_pct'}
