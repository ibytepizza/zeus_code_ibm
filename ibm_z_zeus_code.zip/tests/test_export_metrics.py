from pathlib import Path
import csv
import json
import pytest

from export_model_metrics import build_report, main

ROOT = Path(__file__).parents[1]


def test_report_has_four_models_and_holdout_predictions(tmp_path):
    main(['--data', str(ROOT/'data/meteostat_2024.csv'),
          '--artifacts',str(ROOT/'artifacts'),'--output',str(tmp_path)])
    with (tmp_path/'model_metrics.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    with (tmp_path/'holdout_predictions.csv').open(encoding='utf-8-sig',newline='') as f:
        detail=list(csv.DictReader(f))
    assert len(rows)==4
    assert len(detail)==282
    assert {r['target'] for r in rows}=={
        'daily_low_temperature_c','daily_high_temperature_c',
        'daily_low_humidity_pct','daily_high_humidity_pct'}
    expected={'daily_low_temperature_c':(1.5291,72.46),
              'daily_high_temperature_c':(2.3899,56.52),
              'daily_low_humidity_pct':(8.9167,38.89),
              'daily_high_humidity_pct':(4.0967,73.61)}
    for row in rows:
        mae,accuracy=expected[row['target']]
        assert float(row['mae'])==pytest.approx(mae,abs=.001)
        assert float(row['strict_tolerance_accuracy_pct'])==pytest.approx(accuracy,abs=.01)
        assert 'r2' in row and 'baseline_mae' in row
        assert row['beats_baseline_mae'] in ('True','False')
    assert all(float(row['absolute_error'])>=0 for row in detail)


def test_report_rejects_incorrect_artifacts(tmp_path):
    for name in ('low_temperature','high_temperature','low_humidity','high_humidity'):
        for ext in ('.json',):
            source=ROOT/f'artifacts/{name}{ext}'
            (tmp_path/source.name).write_bytes(source.read_bytes())
        suffix='_c' if 'temperature' in name else '_pct'
        source=ROOT/f'artifacts/holdout_daily_{name}{suffix}.csv'
        (tmp_path/source.name).write_bytes(source.read_bytes())
    path=tmp_path/'low_temperature.json'
    edited=json.loads(path.read_text())
    edited['n_holdout_days']=99
    path.write_text(json.dumps(edited))
    with pytest.raises(ValueError,match='differs from recalculated'):
        build_report(ROOT/'data/meteostat_2024.csv',tmp_path)
