from datetime import date
from pathlib import Path
import pandas as pd
import pytest
import asyncio
import httpx
from fastapi.testclient import TestClient
from climate_guard.data import read_hourly, TARGETS, normalize_hourly
from climate_guard.features import make_feature_frame, daily_target
from climate_guard.modelling import forecast_all, train_one, MODEL_FILES
from climate_guard.qc import scan_hourly
from climate_guard.seasonal import get_outlook, OutlookUnavailable, _check_month
from climate_guard.api import app

BASE = Path(__file__).parents[1]
DATA = BASE / 'data' / 'meteostat_2024.csv'


def test_input_and_derived_targets():
    df = read_hourly(DATA)
    assert df.shape[0] == 8784
    assert df.temperature.isna().sum() == 432
    assert len(TARGETS) == 4
    assert daily_target(df, 'daily_low_temperature_c').isna().sum() == 18
    assert daily_target(df, 'daily_high_temperature_c').isna().sum() == 18
    assert daily_target(df, 'daily_low_humidity_pct').between(0,100).all()
    assert daily_target(df, 'daily_high_humidity_pct').between(0,100).all()
    assert (daily_target(df, 'daily_low_humidity_pct') <= daily_target(df,'daily_high_humidity_pct')).all()


def test_lag_only_no_target_leakage():
    df = read_hourly(DATA)
    feats = make_feature_frame(df)
    changed = df.copy()
    changed.loc[changed.obs_date.eq(pd.Timestamp('2024-07-10')), 'temperature'] = -888
    changed.loc[changed.obs_date.eq(pd.Timestamp('2024-07-10')), 'relative_humidity'] = -888
    for target in TARGETS:
        changed[target] = -999
    # Even changes in other daily summary columns cannot leak into features.
    changed['daily_mean_humidity_pct'] = -999
    alternate = make_feature_frame(changed)
    pd.testing.assert_series_equal(feats.loc['2024-07-10'], alternate.loc['2024-07-10'])
    assert not any('daily_' in col or 'source' in col for col in feats.columns)
    assert feats.loc['2024-07-11', 'humidity_mean_lag1'] != alternate.loc['2024-07-11', 'humidity_mean_lag1']


def test_quality_missing_chunks():
    warnings = scan_hourly(read_hourly(DATA), date='2024-06-24', max_findings=500)
    assert any(x['type'] == 'missing_sensor_values' for x in warnings['findings'])
    assert warnings['peer_station_verification']['status'] == 'unavailable'


def test_train_four_models_and_predict(tmp_path):
    for target in TARGETS:
        report = train_one(DATA, tmp_path, target)
        assert report['target'] == target
        assert report['n_labeled_days'] >= 340
        assert (tmp_path / MODEL_FILES[target]).exists()
    pred = forecast_all(DATA, tmp_path)
    assert pred['prediction_date'] == '2025-01-01'
    assert pred['not_live_weather']
    nums = pred['targets']
    assert nums['daily_low_temperature_c'] <= nums['daily_high_temperature_c']
    assert 0 <= nums['daily_low_humidity_pct'] <= nums['daily_high_humidity_pct'] <= 100
    with pytest.raises(ValueError, match='NEXT-DAY'):
        forecast_all(DATA, tmp_path, '2026-10-18')


def test_seasonal_true_forecast_structure_mocked():
    def provider(request):
        assert 'ecmwf_seas5_ensemble_mean' in str(request.url)
        return httpx.Response(200, json={
            'monthly': {'time': ['2026-10-01', '2026-11-01'],
                        'temperature_2m_anomaly': [0.1, 1.2],
                        'precipitation_anomaly': [0.1, -0.3]},
            'monthly_units': {'temperature_2m_anomaly': '°C', 'precipitation_anomaly':'mm'},
        })
    async def run():
        async with httpx.AsyncClient(transport=httpx.MockTransport(provider)) as fake:
            return await get_outlook(2026, 11, today=date(2026, 10, 17), client=fake)
    forecast = asyncio.run(run())
    assert forecast['temperature']['outlook'] == 'warmer_than_normal'
    assert forecast['precipitation']['outlook'] == 'drier_than_normal'
    assert forecast['location_samples'] == 9
    assert forecast['calibrated_probabilities_available'] is False


def test_seasonal_cannot_hindcast_or_extend_unbounded():
    with pytest.raises(ValueError, match='FUTURE'):
        _check_month(2026, 10, date(2026, 10, 17))
    with pytest.raises(ValueError, match='horizon'):
        _check_month(2027, 12, date(2026, 10, 17))


def test_api_basics(monkeypatch):
    monkeypatch.setenv('CLIMATEGUARD_DATA_PATH', str(DATA))
    client = TestClient(app)
    assert client.get('/api/v1/health').status_code == 200
    assert client.get('/api/v1/dataset/summary').json()['temperature_missing'] == 432
    assert client.get('/docs').status_code == 200
    r = client.get('/api/v1/outlook/month?year=2024&month=10')
    assert r.status_code == 422
