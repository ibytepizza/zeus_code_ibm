"""Retrain all ClimateGuard models on the 2024-2026 nine-city reanalysis archive.

Run:  python train_reanalysis.py
      python train_reanalysis.py --data data/reanalysis_hourly_2024_2026.csv --output artifacts

Nothing in the existing package is modified. This script reuses the package's feature
engineering, candidate models, scoring and selection guardrail, and writes artifacts in the
same format (`*.joblib`, `*.json`, `holdout_<target>.csv`, `metrics_summary.json`,
`quality_isolation_forest.joblib`) so the API, dashboard and exporter keep working.

What is different from `climate_guard.train_all`
  * The archive holds nine cities, so every city is converted to the package's hourly schema
    and feature-engineered independently, then the cities are pooled into one training table.
  * Chronological splitting is done by CALENDAR DATE (never by row), so no city can leak
    information about a date that another city is evaluated on.
  * Holdout = last 20% of dates (roughly April to mid-October 2026). Earlier development only
    ever examined 2024, so this is a genuinely unseen period.

Unit harmonisation (so the models keep the units of the original 2024 station file):
  sunshine_duration  seconds per hour  -> minutes per hour   (0-3600 s  -> 0-60 min)
  cloud_cover        percent           -> oktas              (0-100 %   -> 0-8)
  surface_pressure   station-level hPa -> sea-level hPa      (barometric reduction, using the
                                                              elevation in the metadata file)
Daily labels are UTC calendar days. The archive is gridded ECMWF IFS model output, not station
observations.
"""
import argparse
import json
import platform
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from climate_guard.data import TARGETS, normalize_hourly  # noqa: E402
from climate_guard.features import make_feature_frame, daily_target  # noqa: E402
from climate_guard.modelling import (  # noqa: E402
    BASE_COLS, CANDIDATES, MODEL_FILES, TOLERANCES,
    _score, _selected_columns, make_estimator,
)
from climate_guard.qc import ML_COLUMNS, _ml_features  # noqa: E402

DEFAULT_DATA = ROOT / 'data' / 'reanalysis_hourly_2024_2026.csv'
DEFAULT_META = ROOT / 'data' / 'reanalysis_hourly_2024_2026.metadata.json'
SOURCE_NAME = 'reanalysis_hourly_2024_2026.csv (Open-Meteo ECMWF IFS, nine German cities)'


def to_sea_level(pressure_hpa, temp_c, elevation_m):
    """Standard barometric reduction of station-level pressure to mean sea level."""
    ratio = 0.0065 * elevation_m / (temp_c + 0.0065 * elevation_m + 273.15)
    return pressure_hpa * (1.0 - ratio) ** -5.257


def load_city_frames(csv_path, meta_path):
    raw = pd.read_csv(csv_path)
    meta = json.loads(Path(meta_path).read_text(encoding='utf-8'))
    elevation = {loc['name']: float(loc['elevation_m']) for loc in meta['locations']}
    frames = {}
    for city, part in raw.groupby('location', sort=True):
        if city not in elevation:
            raise ValueError(f'No elevation in metadata for {city}')
        mapped = pd.DataFrame({
            'timestamp': part['timestamp_utc'].to_numpy(),
            'temperature': part['temperature_2m'].to_numpy(),
            'relative_humidity': part['relative_humidity_2m'].to_numpy(),
            'precipitation': part['precipitation'].to_numpy(),
            'wind_speed': part['wind_speed_10m'].to_numpy(),
            'peak_wind_gust_speed': part['wind_gusts_10m'].to_numpy(),
            'atmospheric_pressure': to_sea_level(part['surface_pressure'].to_numpy(),
                                                 part['temperature_2m'].to_numpy(), elevation[city]),
            'sunshine_duration': part['sunshine_duration'].to_numpy() / 60.0,
            'cloud_cover': part['cloud_cover'].to_numpy() * 8.0 / 100.0,
            'weather_condition': part['weather_code'].to_numpy(),
        })
        frames[city] = normalize_hourly(mapped)
    return frames


def build_examples(frames, target):
    parts = []
    for city, hourly in frames.items():
        features = make_feature_frame(hourly)
        labels = daily_target(hourly, target)
        table = features.join(labels, how='inner').iloc[7:]  # same warm-up trim as the package
        table = table[table[target].notna()].copy()
        table['location'] = city
        parts.append(table)
    examples = pd.concat(parts).sort_index(kind='stable')
    examples.index.name = 'date'
    return examples


def select_by_date(train, columns, target):
    """Package selection rule, but with forward-chaining folds cut on date boundaries."""
    dates = np.array(sorted(train.index.unique()))
    n = len(dates)
    folds = ((int(n * .55), int(n * .72)), (int(n * .72), n))
    tolerance = TOLERANCES[target]
    candidates = (*CANDIDATES, 'ridge_minimal') if target == 'daily_low_temperature_c' else CANDIDATES
    ranked = []
    for name in candidates:
        predictions, actuals = [], []
        for stop, end in folds:
            fit = train[train.index < dates[stop]]
            validation = train[(train.index >= dates[stop]) & (train.index <= dates[end - 1])]
            cols = _selected_columns(name, columns)
            model = make_estimator(name, target).fit(fit[cols], fit[target])
            predictions.extend(model.predict(validation[cols]))
            actuals.extend(validation[target].to_numpy(dtype=float))
        ranked.append((name, _score(actuals, predictions, tolerance)))
    by_name = dict(ranked)
    baseline = by_name['lag1']
    eligible = [(name, score) for name, score in ranked
                if name != 'lag1' and score['mae'] < baseline['mae'] * .98
                and score['accuracy_pct'] >= baseline['accuracy_pct'] + 1.0]
    selected = sorted(eligible, key=lambda i: (-i[1]['accuracy_pct'], i[1]['mae']))[0][0] if eligible else 'lag1'
    return selected, by_name


def train_target(frames, output_dir, target):
    examples = build_examples(frames, target)
    cols = [c for c in examples.columns if c not in (target, 'location')]
    if any('source' in c or c.startswith('daily_') for c in cols):
        raise RuntimeError('Potential source/target leakage')
    dates = np.array(sorted(examples.index.unique()))
    cut = dates[int(len(dates) * .8)]
    train, holdout = examples[examples.index < cut], examples[examples.index >= cut]
    chosen, candidate_cv = select_by_date(train, cols, target)
    chosen_cols = _selected_columns(chosen, cols)
    model = make_estimator(chosen, target).fit(train[chosen_cols], train[target])
    predicted = model.predict(holdout[chosen_cols])
    baseline = make_estimator('lag1', target).fit(train[cols], train[target]).predict(holdout[cols])
    actual = holdout[target].to_numpy(dtype=float)
    stats = _score(actual, predicted, TOLERANCES[target])
    base_stats = _score(actual, baseline, TOLERANCES[target])
    relaxed = 3. if target.endswith('_temperature_c') else 15.
    stats['relaxed_tolerance_accuracy_pct'] = float(100 * np.mean(np.abs(predicted - actual) <= relaxed))
    stats['relaxed_tolerance'] = relaxed
    stats['prior_day_persistence_mae'] = base_stats['mae']
    stats['outperforms_persistence'] = bool(stats['mae'] < base_stats['mae'])
    stats['baseline_accuracy_pct'] = base_stats['accuracy_pct']
    stats['beats_baseline_accuracy'] = bool(stats['accuracy_pct'] > base_stats['accuracy_pct'])
    # Deployed estimator is refit on every labelled city-day (evaluation above stays on the earlier fit).
    final = make_estimator(chosen, target).fit(examples[chosen_cols], examples[target])
    bundle = {
        'estimator': final, 'target': target, 'features': chosen_cols,
        'validation': {k: round(float(v), 4) if isinstance(v, (float, np.floating)) else v for k, v in stats.items()},
        'selected_model': chosen, 'candidate_cv': candidate_cv, 'baseline_validation': base_stats,
        'training_dates': [str(examples.index.min().date()), str(examples.index.max().date())],
        'holdout_dates': [str(holdout.index.min().date()), str(holdout.index.max().date())],
        'n_labeled_days': int(len(examples)), 'n_training_days': int(len(train)),
        'n_holdout_days': int(len(holdout)), 'n_features_used': len(chosen_cols),
        'trained_sklearn_version': sklearn.__version__, 'trained_python_version': platform.python_version(),
        'horizon': 'one_day_ahead_from_completed_prior_days',
        'daily_label': 'computed from exactly 24 nonmissing hourly readings; missing days excluded',
        'training_dataset': SOURCE_NAME,
        'n_locations': int(examples['location'].nunique()),
        'locations': sorted(examples['location'].unique().tolist()),
        'n_holdout_calendar_days': int(holdout.index.nunique()),
        'counts_note': 'n_labeled_days / n_training_days / n_holdout_days count city-days (calendar days x locations)',
        'data_kind': 'gridded ECMWF IFS model estimates, not station observations',
        'evaluation_note': 'Holdout = last 20% of calendar dates; 2024 was the only period examined in earlier versions.',
    }
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, output_dir / MODEL_FILES[target])
    meta = {k: v for k, v in bundle.items() if k not in ('estimator', 'features')}
    (output_dir / MODEL_FILES[target].replace('.joblib', '.json')).write_text(json.dumps(meta, indent=2))
    pd.DataFrame({
        'target': target,
        'date': [str(v.date()) for v in holdout.index],
        'location': holdout['location'].to_numpy(),
        'actual': actual,
        'predicted': predicted,
        'absolute_error': np.abs(predicted - actual),
        'baseline_predicted': baseline,
        'baseline_absolute_error': np.abs(baseline - actual),
        'within_strict_tolerance': np.abs(predicted - actual) <= TOLERANCES[target],
        'within_relaxed_tolerance': np.abs(predicted - actual) <= relaxed,
    }).to_csv(output_dir / f'holdout_{target}.csv', index=False)
    return meta


def train_quality_model(frames, output_dir):
    features = pd.concat([_ml_features(df) for df in frames.values()], ignore_index=True)
    estimator = make_pipeline(
        SimpleImputer(strategy='median', add_indicator=False),
        IsolationForest(n_estimators=120, contamination=0.02, random_state=42, n_jobs=-1),
    )
    estimator.fit(features)
    path = Path(output_dir) / 'quality_isolation_forest.joblib'
    joblib.dump({'pipeline': estimator, 'features': list(ML_COLUMNS)}, path)
    return {'quality_model': str(path), 'trained_on_hours': int(len(features)),
            'note': 'Unsupervised unusual patterns, not labels for broken sensors',
            'training_dataset': SOURCE_NAME}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--data', type=Path, default=DEFAULT_DATA)
    p.add_argument('--metadata', type=Path, default=DEFAULT_META)
    p.add_argument('--output', type=Path, default=ROOT / 'artifacts')
    a = p.parse_args(argv)
    frames = load_city_frames(a.data, a.metadata)
    print(f'Loaded {len(frames)} cities, {sum(len(f) for f in frames.values())} hourly rows from {a.data.name}')
    scores = {}
    for target in TARGETS:
        result = train_target(frames, a.output, target)
        scores[result['target']] = result
        print(json.dumps(result, indent=2))
    print(json.dumps(train_quality_model(frames, a.output), indent=2))
    (a.output / 'metrics_summary.json').write_text(json.dumps(scores, indent=2))


if __name__ == '__main__':
    main()
