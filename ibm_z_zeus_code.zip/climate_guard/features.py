"""Strict feature allowlist and completed-day targets: never trust precomputed daily labels.

Training uses one label per DATE and only prior days' readings. The supplied
"daily_*" columns and the unrelated targets are never included as features.
"""
import numpy as np
import pandas as pd

OBS_FEATURES = (
    "temperature", "relative_humidity", "precipitation", "wind_speed",
    "peak_wind_gust_speed", "atmospheric_pressure", "sunshine_duration", "cloud_cover",
)


def aggregate_observed_days(hourly: pd.DataFrame) -> pd.DataFrame:
    obs = hourly.set_index("timestamp").sort_index()
    daily = pd.DataFrame(index=pd.date_range(obs.index.min().normalize(), obs.index.max().normalize(), freq="D"))
    g = obs.resample("D")
    mappings = {
        "temperature": ("temp_mean", "mean"),
        "relative_humidity": ("humidity_mean", "mean"),
        "precipitation": ("rain_sum", "sum"),
        "wind_speed": ("wind_mean", "mean"),
        "peak_wind_gust_speed": ("gust_max", "max"),
        "atmospheric_pressure": ("pressure_mean", "mean"),
        "sunshine_duration": ("sunshine_sum", "sum"),
        "cloud_cover": ("cloud_mean", "mean"),
    }
    for source, (new, operation) in mappings.items():
        daily[new] = g[source].sum(min_count=1) if operation == "sum" else getattr(g[source], operation)()
    daily["temp_observed_min"] = g["temperature"].min()
    daily["temp_observed_max"] = g["temperature"].max()
    daily["humidity_observed_min"] = g["relative_humidity"].min()
    daily["humidity_observed_max"] = g["relative_humidity"].max()
    daily["rainy_hours"] = (obs["precipitation"] > 0).resample("D").sum()
    daily["hours_seen"] = g["temperature"].size()
    daily["temp_coverage"] = g["temperature"].count() / 24.0
    daily["humidity_coverage"] = g["relative_humidity"].count() / 24.0
    daily["pressure_observed_delta"] = g["atmospheric_pressure"].last() - g["atmospheric_pressure"].first()
    return daily


def make_feature_frame(hourly: pd.DataFrame) -> pd.DataFrame:
    observed = aggregate_observed_days(hourly)
    dates = pd.date_range(observed.index.min(), observed.index.max() + pd.Timedelta(days=1), freq="D")
    feats = pd.DataFrame(index=dates)
    doy = dates.dayofyear.to_numpy()
    feats["doy_sin"] = np.sin(2 * np.pi * (doy - 1) / 366)
    feats["doy_cos"] = np.cos(2 * np.pi * (doy - 1) / 366)
    feats["month_sin"] = np.sin(2 * np.pi * (dates.month.to_numpy() - 1) / 12)
    feats["month_cos"] = np.cos(2 * np.pi * (dates.month.to_numpy() - 1) / 12)
    aligned = observed.reindex(dates)
    for name in observed.columns:
        previous = aligned[name].shift(1)
        feats[f"{name}_lag1"] = previous
        if name in ("temp_mean", "humidity_mean", "rain_sum", "wind_mean", "pressure_mean", "cloud_mean"):
            feats[f"{name}_prev3_avg"] = previous.rolling(3, min_periods=1).mean()
            feats[f"{name}_prev7_avg"] = previous.rolling(7, min_periods=1).mean()
    # Additional strictly past-day observations available at forecasting time.
    indexed = hourly.set_index("timestamp").sort_index()
    for sensor, prefix in (("temperature", "t"), ("relative_humidity", "rh"),
                           ("atmospheric_pressure", "p")):
        pivot = indexed[sensor].groupby([indexed.index.normalize(), indexed.index.hour]).mean().unstack()
        for hour in (0, 6, 12, 15, 18, 21, 23):
            hourly_value = pivot[hour].reindex(dates) if hour in pivot.columns else pd.Series(np.nan, index=dates)
            feats[f"{prefix}_{hour:02d}_lag1"] = hourly_value.shift(1)
    for name in ("temp_observed_min", "temp_observed_max",
                 "humidity_observed_min", "humidity_observed_max"):
        series = observed[name].reindex(dates)
        for lag in (2, 3):
            feats[f"{name}_lag{lag}"] = series.shift(lag)
        for window in (3, 5, 7):
            feats[f"{name}_avg{window}"] = series.shift(1).rolling(window, min_periods=1).mean()
    feats["temp_evening_trend"] = feats["t_23_lag1"] - feats["t_18_lag1"]
    feats["humidity_evening_trend"] = feats["rh_23_lag1"] - feats["rh_18_lag1"]
    return feats


def daily_target(hourly: pd.DataFrame, target: str) -> pd.Series:
    # Exactly 24 hours of non-null readings required to label a day. Especially
    # important for the six intentional 72-hour temperature gaps.
    base = {
        "daily_low_temperature_c": ("temperature", "min"),
        "daily_high_temperature_c": ("temperature", "max"),
        "daily_low_humidity_pct": ("relative_humidity", "min"),
        "daily_high_humidity_pct": ("relative_humidity", "max"),
    }
    if target not in base:
        raise ValueError(f"Unknown target {target}")
    sensor, operation = base[target]
    g = hourly.groupby("obs_date", sort=True)[sensor]
    y = getattr(g, operation)().where(g.count().eq(24))
    y.name = target
    return y
