"""Independent model training entry points. Each uses only its own target label."""
