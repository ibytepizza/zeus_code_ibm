"""Independent regressor: tomorrow's MAX relative humidity (%)."""
import argparse
from climate_guard.modelling import train_one
TARGET = "daily_high_humidity_pct"

def train(data_path, output_dir="artifacts"):
    return train_one(data_path, output_dir, TARGET)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--data", required=True)
    p.add_argument("--output", default="artifacts")
    a = p.parse_args()
    print(train(a.data, a.output))
