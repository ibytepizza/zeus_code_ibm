"""Independent low-temperature regressor. Standalone: python -m climate_guard.models.low_temperature --data ..."""
import argparse
from climate_guard.modelling import train_one
TARGET = "daily_low_temperature_c"

def train(data_path, output_dir="artifacts"):
    return train_one(data_path, output_dir, TARGET)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--output", default="artifacts")
    a = p.parse_args()
    print(train(a.data, a.output))
