"""AWS rules + rolling statistics + optional IsolationForest; no fabricated peer verification.

Sensor failure is a *hypothesis* until corroborated by independent station/instrument.
Unit conventions: temperature °C, humidity %, pressure hPa, wind km/h,
precipitation mm. Change QC_SETTINGS only after verifying source units.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from .data import read_hourly

QC_SETTINGS = {
    "temperature": ("°C", -90, 65),
    "relative_humidity": ("%", 0, 100),
    "precipitation": ("mm", 0, 500),
    "wind_speed": ("km/h", 0, 400),
    "peak_wind_gust_speed": ("km/h", 0, 500),
    "atmospheric_pressure": ("hPa", 800, 1100),
}
SPIKE_DIFF = {"temperature": 8.0, "relative_humidity": 35.0, "atmospheric_pressure": 8.0}
FROZEN_HOURS = 6
ML_COLUMNS = (
    "temperature", "relative_humidity", "precipitation", "wind_speed",
    "peak_wind_gust_speed", "atmospheric_pressure", "cloud_cover",
    "temperature_delta", "humidity_delta", "pressure_delta",
)


def _ml_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df[["temperature", "relative_humidity", "precipitation", "wind_speed",
            "peak_wind_gust_speed", "atmospheric_pressure", "cloud_cover"]].copy()
    x["temperature_delta"] = df["temperature"].diff().abs()
    x["humidity_delta"] = df["relative_humidity"].diff().abs()
    x["pressure_delta"] = df["atmospheric_pressure"].diff().abs()
    gaps = df["timestamp"].diff().dt.total_seconds().div(3600)
    x.loc[gaps.ne(1), ["temperature_delta", "humidity_delta", "pressure_delta"]] = np.nan
    return x[list(ML_COLUMNS)]


def train_isolation_forest(csv_path: str | Path, output_dir: str | Path) -> dict:
    df = read_hourly(csv_path)
    x = _ml_features(df)
    estimator = make_pipeline(
        SimpleImputer(strategy="median", add_indicator=False),
        IsolationForest(n_estimators=120, contamination=0.02, random_state=42, n_jobs=-1),
    )
    estimator.fit(x)
    path = Path(output_dir) / "quality_isolation_forest.joblib"
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": estimator, "features": list(ML_COLUMNS)}, path)
    return {"quality_model": str(path), "trained_on_hours": int(len(df)),
            "note": "Unsupervised unusual patterns, not labels for broken sensors"}


def _event(kind: str, sensor: str, start: pd.Timestamp, end: pd.Timestamp,
           severity: str, confidence: str, evidence: str) -> dict:
    return {"type": kind, "sensor": sensor, "start": start.isoformat(),
            "end": end.isoformat(), "severity": severity,
            "confidence": confidence, "explanation": evidence}


def _segments(mask: pd.Series, times: pd.Series):
    """Yield consecutive hourly True segments; separate missing timestamps."""
    mask = mask.fillna(False).to_numpy(dtype=bool)
    times = pd.to_datetime(times).reset_index(drop=True)
    start = None
    for i, flagged in enumerate(mask):
        contiguous = i > 0 and (times.iloc[i] - times.iloc[i-1]) == pd.Timedelta(hours=1)
        if start is not None and (not flagged or not contiguous):
            yield start, i-1
            start = None
        if flagged and start is None:
            start = i
    if start is not None:
        yield start, len(mask)-1


def scan_hourly(df: pd.DataFrame, model_file: str | Path | None = None,
                date: str | None = None, max_findings: int = 150) -> dict:
    """Analyze a contiguous source series, then optionally filter output to date.

    For correct rolling statistics, pass the FULL history; filters only emitted
    events. Nearby-station corroboration is not possible without station data.
    """
    df = df.sort_values("timestamp").reset_index(drop=True)
    issues = []
    for sensor, (unit, lower, upper) in QC_SETTINGS.items():
        s = df[sensor]
        bad = s.notna() & ~s.between(lower, upper)
        for i in np.flatnonzero(bad.to_numpy()):
            issues.append(_event("invalid_physical_range", sensor, df.loc[i, "timestamp"],
                                 df.loc[i, "timestamp"], "high", "high",
                                 f"{s.iloc[i]:g} {unit} is outside broad physical validation bounds [{lower}, {upper}]."))
    # Missing runs are separated from actual storm/weather events.
    for sensor in ("temperature", "relative_humidity", "atmospheric_pressure"):
        for start, end in _segments(df[sensor].isna(), df["timestamp"]):
            if end - start + 1 < 2:
                continue
            hours = end - start + 1
            issues.append(_event("missing_sensor_values", sensor, df.loc[start, "timestamp"],
                                 df.loc[end, "timestamp"], "high" if hours >= 24 else "medium",
                                 "high", f"{hours} hourly measurements are absent; may indicate outage, ingestion loss, or intentionally masked data. Not proof of failed hardware."))
    # Consecutive unchanging readings. Stable zero rain not interpreted as sensor freeze.
    for sensor in ("temperature", "relative_humidity", "atmospheric_pressure"):
        s = df[sensor]
        repeat = s.eq(s.shift(1)) & s.notna()
        discontinuity = df["timestamp"].diff().ne(pd.Timedelta(hours=1))
        repeat.loc[discontinuity] = False
        for start, end in _segments(repeat, df["timestamp"]):
            run_start = max(0, start - 1)
            hours = end - run_start + 1
            if hours >= FROZEN_HOURS:
                issues.append(_event("possible_frozen_sensor", sensor, df.loc[run_start, "timestamp"],
                                     df.loc[end, "timestamp"], "medium", "low",
                                     f"Unchanging {sensor} for {hours} consecutive hours at recorded precision; stable weather can do this too."))
    # Rate-of-change candidate; change by itself does not prove bad sensor.
    time_step = df["timestamp"].diff().dt.total_seconds().div(3600)
    for sensor, threshold in SPIKE_DIFF.items():
        delta = df[sensor].diff()
        jump_mask = delta.abs().ge(threshold) & time_step.eq(1)
        for i in np.flatnonzero(jump_mask.to_numpy()):
            rain = float(df.loc[i, "precipitation"]) if pd.notna(df.loc[i, "precipitation"]) else 0
            gust = float(df.loc[i, "peak_wind_gust_speed"]) if pd.notna(df.loc[i, "peak_wind_gust_speed"]) else 0
            humidity_change = abs(float(df.loc[i, "relative_humidity"] - df.loc[i-1, "relative_humidity"]))
            corroborating = rain >= 1 or gust >= 60 or humidity_change >= 20
            kind = "plausible_extreme_weather" if corroborating else "sensor_spike_candidate"
            evidence = (f"{sensor} changed by {delta.iloc[i]:+.1f} in one hour; "
                        f"rain={rain:.1f} mm, gust={gust:.1f} km/h, humidity change={humidity_change:.1f} points. "
                        + ("Other weather variables support a real weather event." if corroborating
                           else "Other available signals are inconclusive; verify against independent observations."))
            issues.append(_event(kind, sensor, df.loc[i, "timestamp"], df.loc[i, "timestamp"],
                                 "medium", "medium" if corroborating else "low", evidence))
    # Large deviations from trailing rolling statistics; labeled as candidates.
    s = df["temperature"]
    historical_median = s.shift(1).rolling(48, min_periods=36).median()
    past_error = (s - historical_median).abs()
    historical_mad = (s.shift(1) - historical_median.shift(1)).abs().rolling(48, min_periods=36).median()
    robust = past_error / (historical_mad * 1.4826).clip(lower=1.5)
    flags = robust.gt(7) & past_error.gt(9)
    # Report only first point of a cluster to avoid repeated alarms.
    flags = flags & ~flags.shift(1, fill_value=False)
    for i in np.flatnonzero(flags.to_numpy()):
        issues.append(_event("rolling_outlier_candidate", "temperature", df.loc[i, "timestamp"],
                             df.loc[i, "timestamp"], "medium", "low",
                             f"Temperature differs {past_error.iloc[i]:.1f} °C from prior 48-hour median. Diurnal heating/fronts may explain this."))
    # Gradual shift is not identifiable as hardware drift from one station alone.
    temp_24h = s.rolling(24, min_periods=20).mean()
    shift_72h = (temp_24h - temp_24h.shift(72)).abs()
    candidates = shift_72h.gt(12) & shift_72h.shift(1).le(12)
    for i in np.flatnonzero(candidates.fillna(False).to_numpy()):
        issues.append(_event("gradual_weather_or_sensor_shift_unverified", "temperature",
                             df.loc[i, "timestamp"], df.loc[i, "timestamp"], "low", "low",
                             f"24h mean differs {shift_72h.iloc[i]:.1f} °C from 72h earlier. This could be normal seasonal/weather change; independent peer station required to diagnose sensor drift."))
    # Provider/model source changes can masquerade as weather/sensor drift.
    # Keep these alerts separate from physical measurement anomalies.
    for source_col in ("temp_source", "rhum_source", "wpgt_source", "coco_source"):
        if source_col not in df.columns:
            continue
        src = df[source_col].astype("string")
        model_derived = src.eq("dwd_mosmix").fillna(False)
        for start, end in _segments(model_derived, df["timestamp"]):
            hours = end - start + 1
            if hours >= 24:
                issues.append(_event("forecast_derived_source_block", source_col,
                                     df.loc[start, "timestamp"], df.loc[end, "timestamp"],
                                     "medium", "high",
                                     f"{hours} consecutive hours from dwd_mosmix instead of direct observed station data. This is a source/provenance shift, not evidence of a broken sensor."))
    if model_file and Path(model_file).exists():
        bundle = joblib.load(model_file)  # Use only trusted locally produced model files.
        matrix = _ml_features(df)
        prediction = bundle["pipeline"].predict(matrix[bundle["features"]])
        scores = bundle["pipeline"].decision_function(matrix[bundle["features"]])
        # Top strongest unexpected patterns; avoid swamping human-readable issues.
        flagged = np.flatnonzero(prediction == -1)
        strongest = sorted(flagged, key=lambda i: scores[i])[:25]
        for i in strongest:
            issues.append(_event("ml_unusual_pattern", "multiple_weather_sensors",
                                 df.loc[i, "timestamp"], df.loc[i, "timestamp"],
                                 "low", "low", f"IsolationForest anomaly score {scores[i]:.3f}; statistical rarity alone cannot diagnose faulty hardware."))
    if date:
        d = pd.Timestamp(date).normalize()
        issues = [e for e in issues if pd.Timestamp(e["start"]).normalize() <= d <= pd.Timestamp(e["end"]).normalize()]
    issues.sort(key=lambda e: (e["start"], e["type"]))
    total = len(issues)
    return {"findings_count": total, "findings": issues[:max_findings],
            "truncated": total > max_findings,
            "peer_station_verification": {"status": "unavailable",
             "reason": "No coordinates, station ID, or independent nearby-station observations were supplied."},
            "interpretation": "Candidate alerts require context; statistical unusualness and sensor failure are not equivalent."}
