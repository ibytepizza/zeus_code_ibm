"""Next-day model forecasts for each dashboard city, from the bundled ECMWF archive.

Reuses the archive->model-schema conversion from train_reanalysis.py so the inputs are
exactly what the deployed models were trained on. Inference only; nothing is retrained.
"""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

from .modelling import forecast_from_dataframe

ROOT = Path(__file__).resolve().parent.parent
_STALE = ('unseen 2024 dates', 'backtest', 'One year, unspecified station')


@lru_cache(maxsize=2)
def city_forecasts(csv: str, meta: str, artifact_dir: str) -> dict:
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from train_reanalysis import load_city_frames  # reuse the exact training-time conversion
    cities, warnings, prediction_date, based_on = {}, set(), None, None
    for city, hourly in load_city_frames(csv, meta).items():
        result = forecast_from_dataframe(hourly, artifact_dir)
        prediction_date, based_on = result['prediction_date'], result['based_on_through_date']
        cities[city] = result['targets']
        warnings.update(w for w in result['warnings'] if not any(s in w for s in _STALE))
    return {'prediction_date': prediction_date, 'based_on_through_date': based_on,
            'units': {'temperature': '°C', 'humidity': '% RH'}, 'cities': cities,
            'source': 'AtmosIQ daily models applied to the bundled Open-Meteo ECMWF IFS archive (gridded estimates, not station data)',
            'warnings': sorted(warnings),
            'note': ('Inputs end on the archive date above, so this is a next-day forecast for the day after the bundled '
                     'snapshot. It is not live: refresh the archive for a forecast of the current day.')}
