"""Pre-month Germany warmer/drier outlook based on ECMWF SEAS5 forecast anomalies.

Independent of training data. Open-Meteo's anomaly is relative to the *forecast
model's own reforecast climatology*, NOT the 2024 CSV or a station-normal.
Sampling 9 cities is a transparent proxy, NOT a national area-weighted forecast.
Failures are explicit: no fabricated offline outlook, no silent climatology proxy.
Docs: https://open-meteo.com/en/docs/seasonal-forecast-api
"""
from __future__ import annotations
from datetime import date, datetime, timezone
from collections import Counter
import asyncio
import math
import os
import httpx

API_URL = 'https://seasonal-api.open-meteo.com/v1/seasonal'
MODEL = 'ecmwf_seas5_ensemble_mean'
# Fixed, geographically distributed German location sample, NOT the data CSV's
# sensor position. This deliberately does not assert the station location.
GERMANY_SAMPLE_POINTS = (
    ('Hamburg', 53.55, 10.00),
    ('Berlin', 52.52, 13.40),
    ('Hannover', 52.38, 9.73),
    ('Cologne', 50.94, 6.96),
    ('Leipzig', 51.34, 12.37),
    ('Dresden', 51.05, 13.74),
    ('Frankfurt', 50.11, 8.68),
    ('Stuttgart', 48.78, 9.18),
    ('Munich', 48.14, 11.58),
)

class OutlookUnavailable(RuntimeError):
    pass


def _check_month(year: int, month: int, today: date | None = None):
    today = today or datetime.now(timezone.utc).date()
    if not 1 <= month <= 12:
        raise ValueError('month must be from 1 to 12')
    target = date(year, month, 1)
    if target <= today.replace(day=1):
        raise ValueError('Pre-month forecasts require a FUTURE month. No retroactive forecast is offered.')
    delta = (year - today.year) * 12 + (month - today.month)
    if delta > 6:
        raise ValueError('Outside safe configured SEAS5 forecast horizon (max 6 months ahead)')
    return target, today


def _parse_month(payload: dict, target: date):
    monthly = payload.get('monthly')
    if not isinstance(monthly, dict):
        raise OutlookUnavailable('Provider did not return monthly anomalies')
    times = monthly.get('time') or []
    month_key = target.isoformat()[:7]
    matches = [i for i, timestamp in enumerate(times) if str(timestamp)[:7] == month_key]
    if len(matches) != 1:
        raise OutlookUnavailable(f'Provider does not cover requested month {month_key}')
    idx = matches[0]
    temp_arr = monthly.get('temperature_2m_anomaly')
    rain_arr = monthly.get('precipitation_anomaly')
    if temp_arr is None or rain_arr is None:
        raise OutlookUnavailable('Forecast response missing temp or precipitation monthly anomaly')
    try:
        t, p = float(temp_arr[idx]), float(rain_arr[idx])
    except (IndexError, TypeError, ValueError) as e:
        raise OutlookUnavailable('Invalid provider monthly anomaly values') from e
    if not math.isfinite(t) or not math.isfinite(p):
        raise OutlookUnavailable('Provider returned null or nonfinite anomaly value')
    units = payload.get('monthly_units') or {}
    return t, p, units


def summarize_outlook(point_results: list[dict], target: date, as_of: date) -> dict:
    valid = [item for item in point_results if item.get('temperature_anomaly') is not None and item.get('precipitation_anomaly') is not None]
    # More than half of the 9 designated points must be available.
    if len(valid) < 5:
        raise OutlookUnavailable(f'Only {len(valid)} of 9 sampling locations provided valid forecasts; need >=5')
    t_mean = sum(item['temperature_anomaly'] for item in valid) / len(valid)
    p_mean = sum(item['precipitation_anomaly'] for item in valid) / len(valid)
    warm_fraction = sum(item['temperature_anomaly'] > 0 for item in valid) / len(valid)
    dry_fraction = sum(item['precipitation_anomaly'] < 0 for item in valid) / len(valid)
    units = valid[0].get('units', {})
    return {
        'issued_as_of_utc_date': as_of.isoformat(),
        'forecast_month': target.strftime('%Y-%m'),
        'region': 'Germany (9-location spatial proxy)',
        'source': 'Open-Meteo ECMWF SEAS5 ensemble-mean seasonal forecast',
        'model': MODEL,
        'comparison_baseline': 'ECMWF SEAS5 internal retrospective forecast climatology (not 2024 CSV)',
        'temperature': {
            'outlook': 'warmer_than_normal' if t_mean > 0 else 'cooler_than_normal' if t_mean < 0 else 'near_normal',
            'sample_mean_anomaly': round(t_mean, 3),
            'unit': units.get('temperature_2m_anomaly', '°C or K anomaly'),
            'fraction_of_sample_points_warmer': round(warm_fraction, 3),
        },
        'precipitation': {
            'outlook': 'drier_than_normal' if p_mean < 0 else 'wetter_than_normal' if p_mean > 0 else 'near_normal',
            'sample_mean_anomaly': round(p_mean, 3),
            'unit': units.get('precipitation_anomaly', 'provider reported unit'),
            'fraction_of_sample_points_drier': round(dry_fraction, 3),
        },
        'location_samples': len(valid),
        'expected_samples': len(GERMANY_SAMPLE_POINTS),
        'per_location': valid,
        'calibrated_probabilities_available': False,
        'uncertainty': ('Directional outlook from an ensemble mean with limited regional sampling. '
                        'Agreement across cities is NOT an event probability or formal model confidence. '
                        'Seasonal predictions can be wrong and do not forecast daily extremes.'),
        'limitations': [
            'This is not a country-area-weighted spatial average.',
            'The original hourly CSV has no station ID or coordinates; it does not establish a Germany-wide observation.',
            'No trained skill evaluation or 2024-only ML backtest exists for these monthly predictions.',
            'No station-to-station sensor verification is possible using this dataset.',
        ],
    }


async def get_outlook(year: int, month: int, today: date | None = None, client: httpx.AsyncClient | None = None) -> dict:
    target, as_of = _check_month(year, month, today)
    own_client = client is None
    if own_client:
        client = httpx.AsyncClient(timeout=httpx.Timeout(18.0), follow_redirects=False)
    assert client is not None
    semaphore = asyncio.Semaphore(4)

    async def fetch_one(name, lat, lon):
        params = {
            'latitude': lat, 'longitude': lon,
            'monthly': 'temperature_2m_anomaly,precipitation_anomaly',
            'models': MODEL,
            'timezone': 'UTC',
            'forecast_days': 217,
            'cell_selection': 'land',
        }
        key = os.getenv('OPEN_METEO_API_KEY')
        if key:
            params['apikey'] = key
        async with semaphore:
            try:
                response = await client.get(API_URL, params=params)
                response.raise_for_status()
                t, p, units = _parse_month(response.json(), target)
                return {'location': name, 'temperature_anomaly': t, 'precipitation_anomaly': p, 'units': units}
            except (httpx.HTTPError, ValueError, OutlookUnavailable, TypeError, KeyError) as e:
                return {'location': name, 'temperature_anomaly': None,
                        'precipitation_anomaly': None, 'error': str(e)[:250]}

    try:
        result = await asyncio.gather(*(fetch_one(*point) for point in GERMANY_SAMPLE_POINTS))
        summary = summarize_outlook(result, target, as_of)
        summary['failed_locations'] = [v['location'] for v in result if v.get('error')]
        return summary
    finally:
        if own_client:
            await client.aclose()
