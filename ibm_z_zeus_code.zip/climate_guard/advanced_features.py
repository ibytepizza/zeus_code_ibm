"""Hourly-to-daily exogenous features only from observations prior to prediction date.
Never use user-supplied 'daily_*' columns or values from the prediction date.
"""
import numpy as np
import pandas as pd
from .features import make_feature_frame


def advanced_feature_frame(hourly):
    f=make_feature_frame(hourly)
    obs=hourly.set_index('timestamp').sort_index()
    daily=obs.resample('D')
    extra=pd.DataFrame(index=f.index)
    grouped={
        'temperature': 't', 'relative_humidity':'rh', 'atmospheric_pressure':'p',
        'wind_speed':'wind', 'precipitation':'rain', 'cloud_cover':'cloud',
        'peak_wind_gust_speed':'gust','sunshine_duration':'sun'
    }
    for col,key in grouped.items():
        s=obs[col]
        aggregates=daily[col]
        for operation in ('std','last','first'):
            series=getattr(aggregates,operation)().reindex(f.index)
            extra[f'{key}_{operation}_lag1']=series.shift(1)
        pv=s.groupby([s.index.normalize(),s.index.hour]).mean().unstack().reindex(f.index)
        for label, hours in [('night',(0,1,2,3,4,5)),('morning',(6,7,8,9)),
                             ('afternoon',(12,13,14,15,16)),('evening',(18,19,20,21,22,23)),
                             ('late',(21,22,23))]:
            vals=pv.reindex(columns=list(hours))
            for agg in (['mean','min','max'] if col in ('temperature','relative_humidity') else ['mean']):
                extra[f'{key}_{label}_{agg}_lag1']=getattr(vals,agg)(axis=1).shift(1)
    for metric in ['temp_mean', 'humidity_mean', 'temp_observed_min', 'temp_observed_max',
                   'humidity_observed_min','humidity_observed_max','pressure_mean','rain_sum']:
        col=f'{metric}_lag1'
        if col not in f: continue
        for lag in (2,3,4,7):
            if f'{metric}_lag{lag}' not in f:
                extra[f'{metric}_lag{lag}']=f[col].shift(lag-1)
        extra[f'{metric}_d1']=f[col]-f[col].shift(1)
        extra[f'{metric}_d3']=f[col]-f[col].shift(3)
    for side in ('temp','humidity'):
        a='temp' if side=='temp' else 'humidity'
        lo=f'{a}_observed_min_lag1'; hi=f'{a}_observed_max_lag1'
        extra[f'{side}_range_lag1']=f[hi]-f[lo]
    # Approximate dewpoint; only observed yesterday temperature/humidity.
    t=f['temp_mean_lag1']
    rh=np.maximum(1,np.minimum(100,f['humidity_mean_lag1']))
    gamma=np.log(rh/100)+17.625*t/(243.04+t)
    dp=243.04*gamma/(17.625-gamma)
    extra['dewpoint_mean_lag1']=dp
    extra['dewpoint_gap_lag1']=t-dp
    # Trigonometric season and previous-day average proxy are pre-existing.
    return pd.concat([f,extra],axis=1).loc[:,lambda df:~df.columns.duplicated()]


def target_feature_groups(frame,target):
    # Target-safe: all features come from previously observed days.
    base=list(make_feature_frame.__globals__.get('OBS_FEATURES',())) # not used as columns
    core=[c for c in frame if c.endswith('_lag1') or c.endswith('_lag2') or
          c in ('doy_sin','doy_cos','month_sin','month_cos')]
    core=[c for c in core if c in frame]
    if 'temperature' in target:
        focus=[c for c in frame if ('temp' in c or c.startswith('t_') or 'p_' in c or
                                    'pressure' in c or 'cloud' in c or 'sun' in c or
                                    'wind' in c or 'rain' in c or 'dewpoint' in c or
                                    c.endswith('_sin') or c.endswith('_cos'))]
    else:
        focus=[c for c in frame if ('humidity' in c or c.startswith('rh_') or
                                    'temp' in c or c.startswith('t_') or 'dewpoint' in c or
                                    'rain' in c or 'p_' in c or 'pressure' in c or
                                    'cloud' in c or 'sun' in c or
                                    c.endswith('_sin') or c.endswith('_cos'))]
    minimal=[c for c in frame if c in ('doy_sin','doy_cos','month_sin','month_cos') or
             c.endswith(('_observed_min_lag1','_observed_max_lag1')) or
             c in ('temp_mean_lag1','humidity_mean_lag1','rain_sum_lag1',
                   'pressure_mean_lag1','cloud_mean_lag1','sunshine_sum_lag1',
                   't_23_lag1','t_18_lag1','t_06_lag1','rh_23_lag1','rh_18_lag1',
                   'rh_06_lag1','p_23_lag1','p_06_lag1')]
    return {'minimal':list(dict.fromkeys(minimal)),
            'focus':list(dict.fromkeys(focus)),
            'all':list(frame.columns)}
