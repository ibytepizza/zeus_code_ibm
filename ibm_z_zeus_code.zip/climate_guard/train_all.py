"""Train all four independent models + IsolationForest quality model."""
import argparse
import json
from .models import low_temperature, high_temperature, low_humidity, high_humidity
from .qc import train_isolation_forest

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data', default='data/meteostat_2024.csv')
    p.add_argument('--output', default='artifacts')
    a = p.parse_args()
    scores = {}
    for mod in (low_temperature, high_temperature, low_humidity, high_humidity):
        result = mod.train(a.data, a.output)
        scores[result['target']] = result
        print(json.dumps(result, indent=2))
    print(json.dumps(train_isolation_forest(a.data, a.output), indent=2))
    from pathlib import Path
    (Path(a.output) / 'metrics_summary.json').write_text(json.dumps(scores, indent=2))

if __name__ == '__main__':
    main()
