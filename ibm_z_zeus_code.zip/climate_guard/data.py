"""Strict loader for the uploaded 2024 weather file or newly ingested hourly data."""
from pathlib import Path
import pandas as pd

REQUIRED = (
    "temperature", "relative_humidity", "precipitation", "wind_speed",
    "peak_wind_gust_speed", "atmospheric_pressure", "sunshine_duration",
    "cloud_cover", "weather_condition",
)
TARGETS = (
    "daily_low_temperature_c", "daily_high_temperature_c",
    "daily_low_humidity_pct", "daily_high_humidity_pct",
)


def normalize_hourly(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    missing = [name for name in REQUIRED if name not in df.columns]
    if missing:
        raise ValueError(f"Missing required hourly columns: {missing}")
    if all(c in df.columns for c in ("year", "month", "day", "hour")):
        parts = df[["year", "month", "day", "hour"]].apply(pd.to_numeric, errors="coerce")
        if parts.isna().any().any() or not parts["hour"].between(0, 23).all():
            raise ValueError("Invalid date/hour fields")
        ts = pd.to_datetime(parts, errors="coerce")
    elif "timestamp" in df.columns:
        ts = pd.to_datetime(df["timestamp"], errors="coerce", utc=True).dt.tz_convert(None)
    elif "date" in df.columns and "hour" in df.columns:
        hrs = pd.to_numeric(df["hour"], errors="coerce")
        ts = pd.to_datetime(df["date"], errors="coerce") + pd.to_timedelta(hrs, unit="h")
    else:
        raise ValueError("Provide year/month/day/hour, date/hour, or timestamp")
    if ts.isna().any() or ts.duplicated().any():
        raise ValueError("Missing, invalid, or duplicate timestamps")
    df["timestamp"] = ts
    for col in REQUIRED:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.sort_values("timestamp").reset_index(drop=True)
    df["obs_date"] = df["timestamp"].dt.normalize()
    return df


def read_hourly(path: str | Path) -> pd.DataFrame:
    return normalize_hourly(pd.read_csv(path, low_memory=False))
