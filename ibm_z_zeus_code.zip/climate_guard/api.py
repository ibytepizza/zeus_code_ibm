"""Standalone FastAPI app for independent daily ML + AWS quality + seasonal outlook."""
from __future__ import annotations
import os
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
import pandas as pd
from fastapi import APIRouter, FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .data import read_hourly, normalize_hourly
from .modelling import MODEL_FILES, forecast_all, forecast_from_dataframe
from .qc import scan_hourly
from .city_forecast import city_forecasts
from .map_data import build_alerts, build_city_conditions
from .seasonal import get_outlook, OutlookUnavailable, GERMANY_SAMPLE_POINTS

ROOT = Path(__file__).resolve().parent.parent
router = APIRouter(prefix='/api/v1', tags=['AtmosIQ'])
HISTORY_CSV = ROOT / 'data' / 'reanalysis_hourly_2024_2026.csv'
HISTORY_META = ROOT / 'data' / 'reanalysis_hourly_2024_2026.metadata.json'
HISTORY_METRICS = {
    'temperature_2m': ('Temperature', '°C', 'mean'),
    'relative_humidity_2m': ('Relative humidity', '%', 'mean'),
    'precipitation': ('Precipitation', 'mm', 'sum'),
    'wind_speed_10m': ('Wind speed', 'km/h', 'mean'),
    'wind_gusts_10m': ('Wind gusts', 'km/h', 'max'),
    'cloud_cover': ('Cloud cover', '%', 'mean'),
    'sunshine_duration': ('Sunshine', 'hours', 'sum'),
}
DWD_CSV = ROOT / 'data' / 'dwd_station_observations_2024_2026.csv'
DWD_META = ROOT / 'data' / 'dwd_station_observations.metadata.json'
DWD_METRICS = {
    'temperature_2m': ('Temperature', '°C', 'mean', 'temperature_2m_c'),
    'relative_humidity_2m': ('Relative humidity', '%', 'mean', 'relative_humidity_pct'),
    'precipitation': ('Precipitation', 'mm', 'sum', 'precipitation_mm'),
    'wind_speed_10m': ('Wind speed', 'km/h', 'mean', 'wind_speed_kmh'),
}


@lru_cache(maxsize=1)
def dwd_frame():
    if not DWD_CSV.exists():
        raise FileNotFoundError('DWD station observation archive is not installed')
    frame = pd.read_csv(DWD_CSV, parse_dates=['timestamp_utc'])
    frame['date'] = frame['timestamp_utc'].dt.strftime('%Y-%m-%d')
    return frame


@router.get('/weather/stations/summary')
def station_summary():
    import json
    try:
        frame = dwd_frame()
        meta = json.loads(DWD_META.read_text(encoding='utf-8'))
    except (FileNotFoundError, ValueError, OSError) as e:
        raise HTTPException(503, detail=f'DWD station archive unavailable: {e}') from e
    return {'source': meta['source'], 'attribution': meta['attribution'], 'license': meta['license'],
            'data_kind': meta['data_kind'], 'period': meta['period'], 'timezone': meta['timezone'],
            'coverage': meta['coverage'], 'city_stations': meta['city_stations'],
            'variables': list(DWD_METRICS)}


@router.get('/weather/stations/daily')
def station_daily(location: str = Query(...), year: int = Query(..., ge=2024, le=2026),
                  metric: str = Query('temperature_2m')):
    if metric not in DWD_METRICS:
        raise HTTPException(422, detail=f'Unsupported station metric. Choose one of: {", ".join(DWD_METRICS)}')
    try:
        frame = dwd_frame()
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(503, detail=str(e)) from e
    label, unit, aggregation, column = DWD_METRICS[metric]
    subset = frame.loc[(frame['city'] == location) & (frame['timestamp_utc'].dt.year == year), ['date', column]]
    if subset.empty:
        raise HTTPException(404, detail='No station data for this city and year')
    grouped = subset.groupby('date')[column]
    values = grouped.sum(min_count=1) if aggregation == 'sum' else grouped.mean()
    return {'location': location, 'year': year, 'metric': metric, 'label': label, 'unit': unit,
            'aggregation': f'daily {aggregation}', 'source': 'DWD Climate Data Center hourly station observations',
            'data_kind': 'Station observations; 2026 recent data are provisional and may be revised',
            'days': [{'date': date, 'value': None if pd.isna(value) else round(float(value), 2)}
                     for date, value in values.items()]}


@router.get('/weather/stations/compare')
def station_compare(location: str = Query(...), year: int = Query(..., ge=2024, le=2026),
                    metric: str = Query('temperature_2m')):
    if location not in {name for name, *_ in GERMANY_SAMPLE_POINTS}:
        raise HTTPException(404, detail='Unknown city')
    station = station_daily(location, year, metric)
    grid = weather_history_daily(location, year, metric)
    left = {row['date']: row['value'] for row in station['days']}
    right = {row['date']: row['value'] for row in grid['days']}
    matches = [(day, left[day], right[day]) for day in left.keys() & right.keys()
               if left[day] is not None and right[day] is not None]
    if not matches:
        return {'location': location, 'metric': metric, 'year': year, 'matched_days': 0, 'mae': None, 'bias': None}
    errors = [a - b for _, a, b in matches]
    return {'location': location, 'metric': metric, 'year': year, 'matched_days': len(matches),
            'station_source': station['source'], 'grid_source': grid['source'],
            'mae': round(sum(abs(x) for x in errors) / len(errors), 2),
            'bias': round(sum(errors) / len(errors), 2),
            'days': [{'date': d, 'station': a, 'grid_estimate': b, 'difference': round(a-b, 2)}
                     for d, a, b in matches]}


@router.get('/weather/alerts')
def weather_alerts(days: int = Query(14, ge=1, le=365)):
    try:
        frame = dwd_frame()
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(503, detail=str(e)) from e
    coords = {name: (lat, lon) for name, lat, lon in GERMANY_SAMPLE_POINTS}
    return build_alerts(frame, days, coords)


@router.get('/weather/map')
def weather_map(date: str | None = Query(None, description='YYYY-MM-DD; defaults to the latest day with station data')):
    """Observed station conditions and screening risk level for every dashboard city."""
    import json
    try:
        frame = dwd_frame()
        meta = json.loads(DWD_META.read_text(encoding='utf-8'))
    except (FileNotFoundError, ValueError, OSError) as e:
        raise HTTPException(503, detail=f'DWD station archive unavailable: {e}') from e
    try:
        return build_city_conditions(frame, meta, GERMANY_SAMPLE_POINTS, date)
    except ValueError as e:
        raise HTTPException(404, detail=str(e)) from e


@router.get('/weather/stations/model-validation')
def station_model_validation():
    import json
    report_path = ROOT / 'reports' / 'dwd_model_validation.json'
    if not report_path.exists():
        raise HTTPException(404, detail='Run scripts/validate_models_vs_dwd.py to create the station cross-source model evaluation report')
    try:
        return json.loads(report_path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as e:
        raise HTTPException(500, detail=f'Could not read DWD model validation report: {e}') from e


@lru_cache(maxsize=1)
def history_frame():
    if not HISTORY_CSV.exists():
        raise FileNotFoundError('Historical archive is not installed')
    frame = pd.read_csv(HISTORY_CSV, parse_dates=['timestamp_utc'])
    frame['year'] = frame['timestamp_utc'].dt.year
    return frame


@router.get('/weather/history/summary')
def weather_history_summary():
    import json
    try:
        df = history_frame()
        meta = json.loads(HISTORY_META.read_text(encoding='utf-8'))
    except (FileNotFoundError, ValueError, OSError) as e:
        raise HTTPException(503, detail=f'Historical archive unavailable: {e}') from e
    coverage = df.groupby('location').agg(first=('timestamp_utc', 'min'), last=('timestamp_utc', 'max'), rows=('timestamp_utc', 'size'))
    years = sorted(int(y) for y in df['year'].unique())
    return {'source': meta['source'], 'model': meta['model_requested'], 'data_kind': meta['data_kind'],
            'start_date': str(df['timestamp_utc'].min().date()), 'end_date': str(df['timestamp_utc'].max().date()),
            'timezone': meta['timezone'], 'attribution': meta['attribution'], 'years': years,
            'metrics': {key: {'label': value[0], 'unit': value[1]} for key, value in HISTORY_METRICS.items()},
            'locations': [{'name': name, 'first_date': str(row['first'].date()), 'last_date': str(row['last'].date()), 'rows': int(row['rows'])}
                          for name, row in coverage.iterrows()]}


@router.get('/weather/history/daily')
def weather_history_daily(location: str = Query(...), year: int = Query(..., ge=2024, le=2026),
                          metric: str = Query('temperature_2m')):
    if metric not in HISTORY_METRICS:
        raise HTTPException(422, detail=f'Unsupported metric. Choose one of: {", ".join(HISTORY_METRICS)}')
    try:
        df = history_frame()
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(503, detail=str(e)) from e
    if location not in set(df['location'].unique()):
        raise HTTPException(404, detail='Location is not in the historical archive')
    label, unit, aggregation = HISTORY_METRICS[metric]
    subset = df.loc[(df['location'] == location) & (df['year'] == year), ['timestamp_utc', metric]].copy()
    if subset.empty:
        raise HTTPException(404, detail='No data for this location and year')
    subset['date'] = subset['timestamp_utc'].dt.strftime('%Y-%m-%d')
    series = subset.groupby('date')[metric]
    if metric == 'sunshine_duration':
        values = series.sum(min_count=1) / 3600
    elif aggregation == 'sum':
        values = series.sum(min_count=1)
    elif aggregation == 'max':
        values = series.max()
    else:
        values = series.mean()
    data = [{'date': date, 'value': None if pd.isna(value) else round(float(value), 2)} for date, value in values.items()]
    return {'location': location, 'year': year, 'metric': metric, 'label': label, 'unit': unit,
            'aggregation': 'daily sunshine total' if metric == 'sunshine_duration' else f'daily {aggregation}',
            'source': 'Open-Meteo Historical Weather API · ECMWF IFS',
            'attribution': 'Weather data by Open-Meteo.com, licensed under CC BY 4.0',
            'data_kind': 'Gridded model estimates, not station observations', 'days': data}


def paths():
    return (Path(os.getenv('CLIMATEGUARD_DATA_PATH', ROOT / 'data' / 'meteostat_2024.csv')),
            Path(os.getenv('CLIMATEGUARD_MODEL_DIR', ROOT / 'artifacts')))


class HourlyBatch(BaseModel):
    records: list[dict] = Field(min_length=192, max_length=25000)
    prediction_date: str | None = None


class ScanBatch(BaseModel):
    records: list[dict] = Field(min_length=1, max_length=25000)
    date: str | None = None
    limit: int = Field(default=100, ge=1, le=1000)


@router.get('/health')
def health():
    csv, models = paths()
    return {
        'status': 'ready' if csv.exists() and all((models / name).exists() for name in MODEL_FILES.values()) else 'setup_required',
        'dataset_available': csv.exists(),
        'models_available': {target: (models / name).exists() for target, name in MODEL_FILES.items()},
        'monthly_provider': 'external_live_Open_Meteo_ECMWF_SEAS5',
        'monthly_provider_validation': 'not_checked_until_outlook_request',
        'peer_station_verification': 'unavailable_no_station_metadata',
    }


@router.get('/models/metrics')
def model_metrics():
    _, artifacts = paths()
    output, reports = {}, {}
    for target, name in MODEL_FILES.items():
        filename = artifacts / name.replace('.joblib', '.json')
        if not filename.exists():
            raise HTTPException(422, detail=f'Missing model report: {filename.name}')
        import json
        report = json.loads(filename.read_text())
        reports[target] = report
        output[target] = {'selected_model':report['selected_model'],
                          'holdout':report['validation'],
                          'baseline':report['baseline_validation'],
                          'holdout_dates':report['holdout_dates'],
                          'n_holdout_days':report['n_holdout_days']}
    notes = {r.get('evaluation_note') for r in reports.values() if r.get('evaluation_note')}
    return {'evaluation': ' '.join(sorted(notes)) or 'Chronological holdout; exploratory, not an independent test.',
            'is_classification_accuracy':False, 'models':output}


@router.get('/dataset/summary')
def dataset_summary():
    csv, _ = paths()
    try:
        df = read_hourly(csv)
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(422, detail=str(e)) from e
    return {
        'rows': int(len(df)), 'first_timestamp': df['timestamp'].min().isoformat(),
        'last_timestamp': df['timestamp'].max().isoformat(),
        'days': int(df['obs_date'].nunique()),
        'temperature_missing': int(df['temperature'].isna().sum()),
        'humidity_missing': int(df['relative_humidity'].isna().sum()),
        'location': None,
        'note': 'Single 2024 dataset; not a national German multi-year observation dataset',
    }


@router.get('/forecast/next-day')
def forecast_next_day(prediction_date: str | None = Query(default=None, description='YYYY-MM-DD, must follow latest complete day')):
    csv, models = paths()
    try:
        return forecast_all(csv, models, prediction_date)
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise HTTPException(422, detail=str(e)) from e


@router.get('/forecast/cities')
def forecast_cities():
    """Per-city next-day model forecast (ECMWF archive inputs), for the dashboard map."""
    _, models = paths()
    try:
        return city_forecasts(str(HISTORY_CSV), str(HISTORY_META), str(models))
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise HTTPException(422, detail=f'City forecast unavailable: {e}') from e


@router.post('/forecast/next-day')
def forecast_next_day_uploaded(batch: HourlyBatch):
    _, models = paths()
    try:
        dataframe = normalize_hourly(pd.DataFrame(batch.records))
        return forecast_from_dataframe(dataframe, models, batch.prediction_date)
    except (FileNotFoundError, ValueError, KeyError) as e:
        raise HTTPException(422, detail=str(e)) from e


@router.get('/quality/scan')
def quality_scan(date: str | None = None, limit: int = Query(100, ge=1, le=1000)):
    csv, artifacts = paths()
    try:
        return scan_hourly(read_hourly(csv), artifacts / 'quality_isolation_forest.joblib', date, max_findings=limit)
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(422, detail=str(e)) from e


@router.post('/quality/scan')
def quality_scan_uploaded(batch: ScanBatch):
    _, artifacts = paths()
    try:
        return scan_hourly(normalize_hourly(pd.DataFrame(batch.records)),
                           artifacts / 'quality_isolation_forest.joblib', batch.date, max_findings=batch.limit)
    except (FileNotFoundError, ValueError) as e:
        raise HTTPException(422, detail=str(e)) from e


@router.get('/outlook/locations')
def outlook_locations():
    return {
        'label': 'Seasonal outlook sampling locations; not the observation dataset station',
        'locations': [{'name': name, 'latitude': lat, 'longitude': lon}
                      for name, lat, lon in GERMANY_SAMPLE_POINTS],
    }


@router.get('/outlook/next-month')
async def automatic_next_month_outlook():
    today = datetime.now(timezone.utc).date()
    month = today.month % 12 + 1
    year = today.year + (1 if today.month == 12 else 0)
    try:
        return await get_outlook(year, month)
    except OutlookUnavailable as e:
        raise HTTPException(503, detail=f'External seasonal forecast unavailable: {e}') from e


@router.get('/outlook/month')
async def next_month_outlook(year: int = Query(..., ge=2024, le=2200),
                             month: int = Query(..., ge=1, le=12)):
    try:
        return await get_outlook(year, month)
    except ValueError as e:
        raise HTTPException(422, detail=str(e)) from e
    except OutlookUnavailable as e:
        raise HTTPException(503, detail=f'External seasonal forecast unavailable: {e}') from e

app = FastAPI(title='AtmosIQ — Where Weather Meets Intelligence (4 daily ML models + station map + seasonal outlook + AWS QC)', version='5.0.0')
origins = [url.strip() for url in os.getenv('CORS_ALLOW_ORIGINS', '').split(',') if url.strip()]
if origins:
    app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                       allow_methods=['GET', 'POST'], allow_headers=['Content-Type'])
app.include_router(router)

@app.get('/', include_in_schema=False)
def root():
    return FileResponse(ROOT / 'frontend' / 'index.html')

app.mount('/static', StaticFiles(directory=ROOT / 'frontend'), name='static')
