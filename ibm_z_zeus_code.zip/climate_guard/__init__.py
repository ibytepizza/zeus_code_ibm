"""ClimateGuard: four daily weather predictors, AWS quality checks, climate anomaly reference."""
