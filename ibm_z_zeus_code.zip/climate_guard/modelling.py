"""Leakage-safe four-target model selection, chronological evaluation and inference.

Model selection uses *only* rolling validation windows inside the 80% training era;
the last 20% is a separate test set. Never optimize on holdout outcomes.
"""
from pathlib import Path
import json
import platform
import numpy as np
import pandas as pd
import joblib
import sklearn
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor, ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from .data import read_hourly, TARGETS
from .features import make_feature_frame, daily_target

MODEL_FILES = {
    'daily_low_temperature_c': 'low_temperature.joblib',
    'daily_high_temperature_c': 'high_temperature.joblib',
    'daily_low_humidity_pct': 'low_humidity.joblib',
    'daily_high_humidity_pct': 'high_humidity.joblib',
}
BASE_COLS = {
    'daily_low_temperature_c': 'temp_observed_min_lag1',
    'daily_high_temperature_c': 'temp_observed_max_lag1',
    'daily_low_humidity_pct': 'humidity_observed_min_lag1',
    'daily_high_humidity_pct': 'humidity_observed_max_lag1',
}
TOLERANCES = {
    'daily_low_temperature_c': 2.,
    'daily_high_temperature_c': 2.,
    'daily_low_humidity_pct': 5.,
    'daily_high_humidity_pct': 5.,
}

class PriorDayRegressor:
    """A fitted sklearn-like persistence/rolling-day baseline, for fair comparison."""
    def __init__(self, base_col: str, strategy: str = 'lag1'):
        self.base_col = base_col
        self.strategy = strategy

    def fit(self, x, y):
        self.fallback_ = float(np.median(np.asarray(y, dtype=float)))
        return self

    def predict(self, x):
        base = self.base_col
        alt2 = base.replace('_lag1', '_lag2')
        alt3 = base.replace('_lag1', '_lag3')
        if self.strategy == 'lag1':
            raw = x[base]
        elif self.strategy == 'mean2':
            raw = x[[base, alt2]].mean(axis=1)
        elif self.strategy == 'mean3':
            raw = x[[base, alt2, alt3]].mean(axis=1)
        else:
            raise ValueError('Unknown persistence strategy')
        return raw.fillna(self.fallback_).to_numpy(dtype=float)


def make_estimator(name, target):
    if name in ('lag1', 'mean2', 'mean3'):
        return PriorDayRegressor(BASE_COLS[target], name)
    if name == 'ridge_minimal':
        return make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), Ridge(alpha=1))
    if name == 'ridge1':
        return make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), Ridge(alpha=1))
    if name == 'ridge100':
        return make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), Ridge(alpha=100))
    if name == 'rf':
        return RandomForestRegressor(n_estimators=130, max_depth=4, min_samples_leaf=5,
                                     max_features=.8, random_state=17, n_jobs=1)
    if name == 'extra':
        return ExtraTreesRegressor(n_estimators=130, max_depth=4, min_samples_leaf=5,
                                   max_features=.8, random_state=17, n_jobs=1)
    if name == 'hgb':
        return HistGradientBoostingRegressor(max_iter=70, max_leaf_nodes=5,
                min_samples_leaf=15, learning_rate=.05, l2_regularization=5,
                early_stopping=False, random_state=17)
    raise ValueError(f'Unsupported candidate {name}')

CANDIDATES = ('lag1', 'mean2', 'mean3', 'ridge1', 'ridge100', 'rf', 'extra', 'hgb')
# This subset was selected using *only training-period forward-chain validation*.
# Target-specific: the other models retain full-feature options.
MINIMAL_FEATURES = (
    'doy_sin', 'doy_cos', 'month_sin', 'month_cos', 'temp_mean_lag1',
    'humidity_mean_lag1', 'rain_sum_lag1', 'pressure_mean_lag1',
    'sunshine_sum_lag1', 'cloud_mean_lag1',
    'temp_observed_min_lag1', 'temp_observed_max_lag1',
    'humidity_observed_min_lag1', 'humidity_observed_max_lag1',
    't_06_lag1', 't_18_lag1', 't_23_lag1', 'rh_06_lag1',
    'rh_18_lag1', 'rh_23_lag1', 'p_06_lag1', 'p_23_lag1',
)

def _selected_columns(candidate, all_cols):
    return list(MINIMAL_FEATURES) if candidate == 'ridge_minimal' else all_cols



def _score(y, pred, tol):
    actual = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    error = np.abs(pred-actual)
    return {'mae': float(error.mean()),
            'rmse': float(np.sqrt(np.mean((pred-actual)**2))),
            'r2': float(r2_score(actual, pred)),
            'accuracy_pct': float(100*np.mean(error <= tol)),
            'tolerance': tol}


def select_candidate(train, columns, target):
    """Compare candidates on two forward-chaining validation windows, no test peeking."""
    n = len(train)
    folds = ((int(n*.55), int(n*.72)), (int(n*.72), n))
    tolerance = TOLERANCES[target]
    ranked = []
    candidates = (*CANDIDATES, 'ridge_minimal') if target == 'daily_low_temperature_c' else CANDIDATES
    for name in candidates:
        predictions, actuals = [], []
        for stop, end in folds:
            fit, validation = train.iloc[:stop], train.iloc[stop:end]
            chosen_cols = _selected_columns(name, columns)
            model = make_estimator(name, target).fit(fit[chosen_cols], fit[target])
            predictions.extend(model.predict(validation[chosen_cols]))
            actuals.extend(validation[target].to_numpy(dtype=float))
        ranked.append((name, _score(actuals, predictions, tolerance)))
    by_name = dict(ranked)
    baseline = by_name['lag1']
    # Guardrail: only replace persistence when both absolute error and useful-hit
    # rate improve. Prevents picking a model that wins on a single metric by luck.
    eligible = [(name, score) for name, score in ranked
                if name != 'lag1' and score['mae'] < baseline['mae']*.98
                and score['accuracy_pct'] >= baseline['accuracy_pct']+1.0]
    selected = sorted(eligible, key=lambda item: (-item[1]['accuracy_pct'], item[1]['mae']))[0][0] if eligible else 'lag1'
    return selected, {name: score for name, score in ranked}


def train_one(csv_path, output_dir, target):
    if target not in TARGETS:
        raise ValueError(f'Unsupported target {target}')
    hourly = read_hourly(csv_path)
    features = make_feature_frame(hourly)
    labels = daily_target(hourly, target)
    candidates = features.join(labels, how='inner').iloc[7:]
    examples = candidates[candidates[target].notna()].copy()
    if len(examples) < 80:
        raise ValueError(f'Need >=80 labeled days; received {len(examples)}')
    cols = list(features.columns)
    if any('source' in col or col.startswith('daily_') for col in cols):
        raise RuntimeError('Potential source/target leakage')
    split = int(len(examples)*.8)
    train, holdout = examples.iloc[:split], examples.iloc[split:]
    chosen, candidate_cv = select_candidate(train, cols, target)
    chosen_cols = _selected_columns(chosen, cols)
    model = make_estimator(chosen, target).fit(train[chosen_cols], train[target])
    predicted = model.predict(holdout[chosen_cols])
    baseline = make_estimator('lag1', target).fit(train[cols], train[target]).predict(holdout[cols])
    stats = _score(holdout[target], predicted, TOLERANCES[target])
    base_stats = _score(holdout[target], baseline, TOLERANCES[target])
    # Relaxed tolerances disclosed separately, never named "accuracy" without units.
    relaxed = 3. if target.endswith('_temperature_c') else 15.
    stats['relaxed_tolerance_accuracy_pct'] = float(100*np.mean(np.abs(predicted-holdout[target].to_numpy()) <= relaxed))
    stats['relaxed_tolerance'] = relaxed
    stats['prior_day_persistence_mae'] = base_stats['mae']
    stats['outperforms_persistence'] = bool(stats['mae'] < base_stats['mae'])
    stats['baseline_accuracy_pct'] = base_stats['accuracy_pct']
    stats['beats_baseline_accuracy'] = bool(stats['accuracy_pct'] > base_stats['accuracy_pct'])
    # Trained model only deployed AFTER this untouched holdout test; evaluation
    # metrics remain attached to the earlier fit, not the refit on all dates.
    final = make_estimator(chosen, target).fit(examples[chosen_cols], examples[target])
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    bundle = {
        'estimator': final, 'target': target, 'features': chosen_cols,
        'validation': {k: round(float(v), 4) if isinstance(v,(float,np.floating)) else v for k,v in stats.items()},
        'selected_model': chosen, 'candidate_cv': candidate_cv,
        'baseline_validation': base_stats,
        'training_dates': [str(examples.index[0].date()), str(examples.index[-1].date())],
        'holdout_dates': [str(holdout.index[0].date()), str(holdout.index[-1].date())],
        'n_labeled_days': int(len(examples)), 'n_training_days':int(len(train)),
        'n_holdout_days':int(len(holdout)), 'n_features_used': len(chosen_cols),
        'trained_sklearn_version': sklearn.__version__, 'trained_python_version':platform.python_version(),
        'horizon':'one_day_ahead_from_completed_prior_days',
        'daily_label':'computed from exactly 24 nonmissing hourly readings; missing days excluded',
    }
    joblib.dump(bundle, output_dir/MODEL_FILES[target])
    meta = {k:v for k,v in bundle.items() if k not in ('estimator','features')}
    (output_dir/MODEL_FILES[target].replace('.joblib','.json')).write_text(json.dumps(meta, indent=2))
    details = pd.DataFrame({
        'target':target,
        'date':[str(v.date()) for v in holdout.index],
        'actual':holdout[target].to_numpy(dtype=float),
        'predicted':predicted,
        'absolute_error':np.abs(predicted-holdout[target].to_numpy(dtype=float)),
        'baseline_predicted':baseline,
        'baseline_absolute_error':np.abs(baseline-holdout[target].to_numpy(dtype=float)),
        'within_strict_tolerance':np.abs(predicted-holdout[target].to_numpy(dtype=float)) <= TOLERANCES[target],
        'within_relaxed_tolerance':np.abs(predicted-holdout[target].to_numpy(dtype=float)) <= relaxed,
    })
    details.to_csv(output_dir/f'holdout_{target}.csv', index=False)
    return meta


def forecast_all(csv_path, artifact_dir, prediction_date=None):
    return forecast_from_dataframe(read_hourly(csv_path), artifact_dir, prediction_date)


def forecast_from_dataframe(hourly_df, artifact_dir, prediction_date=None):
    frame = make_feature_frame(hourly_df)
    last_day = hourly_df['obs_date'].max()
    requested = pd.Timestamp(prediction_date).normalize() if prediction_date else last_day + pd.Timedelta(days=1)
    if requested != last_day + pd.Timedelta(days=1):
        raise ValueError('A NEXT-DAY forecast must be for exactly the calendar day after the latest observations')
    if requested not in frame.index or len(hourly_df) < 24*8:
        raise ValueError('Insufficient prior hourly history')
    latest_rows = hourly_df[hourly_df['obs_date'].eq(last_day)]
    if len(latest_rows) != 24:
        raise ValueError('The latest observed day must contain 24 hourly rows before next-day inference')
    row = frame.loc[[requested]]
    result, warnings, trained_through = {}, [], []
    for target, filename in MODEL_FILES.items():
        path = Path(artifact_dir)/filename
        if not path.exists():
            raise FileNotFoundError(f'Missing model file: {filename}')
        bundle = joblib.load(path)  # local trusted artifacts only
        if bundle['trained_sklearn_version'] != sklearn.__version__:
            raise ValueError(f'{filename} sklearn version mismatch; retrain')
        trained_through.append(pd.Timestamp(bundle['training_dates'][1]))
        value = float(bundle['estimator'].predict(row[bundle['features']])[0])
        if target.endswith('humidity_pct'):
            value=float(np.clip(value,0,100))
        result[target]=round(value,2)
        if not bundle['validation'].get('outperforms_persistence',False):
            warnings.append(f'{target}: selected model did not beat simple persistence MAE on unseen 2024 dates')
        if not bundle['validation'].get('beats_baseline_accuracy',False):
            warnings.append(f'{target}: strict-tolerance score does not beat previous-day persistence on 2024 backtest')
        if bundle['validation'].get('accuracy_pct',0)<70:
            warnings.append(f'{target}: held-out strict-tolerance hit rate below 70%')
    for kind,low,high in [('temperature','daily_low_temperature_c','daily_high_temperature_c'),
                          ('humidity','daily_low_humidity_pct','daily_high_humidity_pct')]:
        if result[low] > result[high]:
            warnings.append(f'Independent {kind} models returned low > high; midpoint consistency correction applied')
            midpoint=round((result[low]+result[high])/2,2)
            result[low]=result[high]=midpoint
    if requested<=max(trained_through):
        warnings.append('Predicted date overlaps historical training range: in-sample illustration')
    warnings.append('One year, unspecified station: cannot validate nationwide Germany forecasting')
    return {'prediction_date':str(requested.date()),
            'based_on_through_date':str(last_day.date()),
            'targets':result,'units':{'temperature':'°C','humidity':'% RH'},
            'training_data_last_year':2024,
            'not_live_weather':last_day<pd.Timestamp.now().normalize()-pd.Timedelta(days=1),
            'warnings':warnings}
