"""Per-city observed conditions, screening risk levels and alerts for the dashboard map.

Everything here is derived from the bundled DWD station observations. Nothing is
simulated. Thresholds are illustrative dashboard screening rules, not DWD warnings.
Kept free of FastAPI so it can be unit-tested with pandas only.
"""
from __future__ import annotations

import pandas as pd

# kind: (column, aggregation, comparison, watch, alert, unit, message)
RULES = {
    'heat': ('temperature_2m_c', 'max', 'ge', 25.0, 30.0, '°C', 'Daily maximum temperature reached 30 °C'),
    'frost': ('temperature_2m_c', 'min', 'le', 3.0, 0.0, '°C', 'Daily minimum temperature fell to 0 °C or below'),
    'heavy_rain': ('precipitation_mm', 'sum', 'ge', 10.0, 20.0, 'mm', 'Daily precipitation reached 20 mm'),
    'strong_wind': ('wind_speed_kmh', 'max', 'ge', 45.0, 60.0, 'km/h', 'Maximum hourly wind speed reached 60 km/h'),
}
MIN_HOURS = 18  # a city-day needs this many hourly values per variable to be treated as complete
LEVEL_RANK = {'normal': 0, 'watch': 1, 'alert': 2}


def _agg(series: pd.Series, how: str):
    if how == 'sum':
        return series.sum(min_count=1)
    return getattr(series, how)()


def _num(value, digits=1):
    return None if value is None or pd.isna(value) else round(float(value), digits)


def _severity(kind: str, value: float) -> float:
    """Value relative to the alert threshold (>=1 means alert). Comparable across kinds."""
    _, _, cmp, _, alert, *_ = RULES[kind]
    if cmp == 'ge':
        return value / alert
    # frost: 0 °C is the threshold, so measure distance below it on a 5 K scale
    return 1.0 + (alert - value) / 5.0


def _level(kind: str, value) -> str:
    if value is None or pd.isna(value):
        return 'normal'
    _, _, cmp, watch, alert, *_ = RULES[kind]
    if cmp == 'ge':
        return 'alert' if value >= alert else 'watch' if value >= watch else 'normal'
    return 'alert' if value <= alert else 'watch' if value <= watch else 'normal'


def complete_days(frame: pd.DataFrame) -> pd.DataFrame:
    """Per city-day aggregates, keeping only variables with enough hourly coverage."""
    g = frame.groupby(['city', 'date'])
    out = pd.DataFrame(index=g.size().index)
    for kind, (col, how, *_rest) in RULES.items():
        agg = g[col].sum(min_count=1) if how == 'sum' else getattr(g[col], how)()
        out[kind] = agg.where(g[col].count() >= MIN_HOURS)
    out['humidity_mean'] = g['relative_humidity_pct'].mean().where(g['relative_humidity_pct'].count() >= MIN_HOURS)
    out['temp_mean'] = g['temperature_2m_c'].mean().where(g['temperature_2m_c'].count() >= MIN_HOURS)
    out['temp_max'], out['temp_min'] = out['heat'], out['frost']
    out['rain_mm'], out['wind_max_kmh'] = out['heavy_rain'], out['strong_wind']
    return out.reset_index()


def build_alerts(frame: pd.DataFrame, days: int = 14, coords: dict | None = None) -> dict:
    """Threshold crossings on complete city-days in the last `days` days, most severe first."""
    coords = coords or {}
    end = frame['timestamp_utc'].max()
    start = end - pd.Timedelta(days=days - 1)
    daily = complete_days(frame.loc[frame['timestamp_utc'] >= start.normalize()])
    alerts = []
    for r in daily.itertuples(index=False):
        for kind, (_, _, _, _, alert, unit, message) in RULES.items():
            value = getattr(r, kind)
            if pd.notna(value) and _level(kind, value) == 'alert':
                lat_lon = coords.get(r.city, (None, None))
                alerts.append({'city': r.city, 'date': r.date, 'type': kind, 'value': round(float(value), 1),
                               'threshold': alert, 'unit': unit, 'message': message,
                               'severity': round(_severity(kind, float(value)), 2),
                               'latitude': lat_lon[0], 'longitude': lat_lon[1]})
    alerts.sort(key=lambda a: (a['date'], a['severity']), reverse=True)
    return {'source': 'DWD station observations',
            'period_start': str(start.date()), 'period_end': str(end.date()),
            'note': 'Dashboard screening thresholds for this demo; they are not official DWD warnings.',
            'alerts': alerts[:100]}


def build_city_conditions(frame: pd.DataFrame, meta: dict, points, date: str | None = None) -> dict:
    """Observed conditions + screening level per city for one day (default: latest day with data).

    `points` is an iterable of (city, latitude, longitude) city-centre coordinates.
    """
    daily = complete_days(frame)
    available = sorted(daily['date'].unique())
    if date is None:
        # latest day on which at least one city has a complete temperature record
        valid = daily.loc[daily['temp_max'].notna(), 'date']
        date = str(valid.max()) if not valid.empty else available[-1]
    elif date not in available:
        raise ValueError(f'No station data for {date}; available {available[0]} to {available[-1]}')
    stations = meta.get('city_stations', {})
    cities = []
    for name, lat, lon in points:
        row = daily.loc[(daily['city'] == name) & (daily['date'] == date)]
        st = stations.get(name, {})
        tu = st.get('TU', {})
        entry = {'name': name, 'latitude': lat, 'longitude': lon,
                 'station': {'name': tu.get('station_name'), 'latitude': tu.get('latitude'),
                             'longitude': tu.get('longitude'), 'distance_from_city_km': tu.get('distance_from_city_km')},
                 'observed': None, 'risk': {'level': 'unknown', 'reasons': []}}
        if not row.empty:
            r = row.iloc[0]
            reasons, level = [], 'normal'
            for kind, (_, _, _, _, alert, unit, _msg) in RULES.items():
                v = r[kind]
                lv = _level(kind, v)
                if lv != 'normal':
                    reasons.append({'type': kind, 'level': lv, 'value': _num(v), 'unit': unit,
                                    'severity': round(_severity(kind, float(v)), 2)})
                    if LEVEL_RANK[lv] > LEVEL_RANK[level]:
                        level = lv
            have_any = any(pd.notna(r[k]) for k in RULES)
            entry['observed'] = {'temp_max_c': _num(r['temp_max']), 'temp_min_c': _num(r['temp_min']),
                                 'temp_mean_c': _num(r['temp_mean']), 'rain_mm': _num(r['rain_mm']),
                                 'wind_max_kmh': _num(r['wind_max_kmh']), 'humidity_mean_pct': _num(r['humidity_mean'], 0)}
            reasons.sort(key=lambda x: x['severity'], reverse=True)
            entry['risk'] = {'level': level if have_any else 'unknown', 'reasons': reasons}
        cities.append(entry)
    counts = {lvl: sum(c['risk']['level'] == lvl for c in cities) for lvl in ('alert', 'watch', 'normal', 'unknown')}
    return {'date': date, 'available_from': available[0], 'available_to': available[-1],
            'source': 'DWD Climate Data Center hourly station observations',
            'data_kind': 'Observed station values (bundled snapshot, not live). 2026 values are provisional.',
            'attribution': meta.get('attribution'),
            'rules': {k: {'watch': v[3], 'alert': v[4], 'unit': v[5], 'comparison': v[2]} for k, v in RULES.items()},
            'summary': counts, 'cities': cities,
            'note': 'Risk levels are illustrative screening rules on observed daily values, not official DWD warnings.'}
