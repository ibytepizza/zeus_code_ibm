# AtmosIQ — Where Weather Meets Intelligence

*(IBM Z Datathon project; formerly "ClimateGuard AI Germany". Package name `climate_guard` is unchanged.)*

**Four independent next-day models:** minimum temperature (°C), maximum temperature (°C), minimum relative humidity (%), maximum relative humidity (%). **AWS sensor-quality detector** and **pre-month German warm/dry seasonal outlook** remain available through FastAPI.

## Quick start and 3-minute demo

```bash
python3.13 -m venv .venv && . .venv/bin/activate      # Windows: py -3.13 -m venv .venv ; .\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn climate_guard.api:app --host 0.0.0.0 --port 8000
# open http://localhost:8000
```

Suggested demo flow:

1. **Map (top left).** Dark satellite basemap (Esri World Imagery, no API key; switchable to a CARTO dark map, which is also the automatic fallback) with nine German cities coloured by *observed DWD station values* for the latest day in the bundled archive. Switch **Risk / Temp / Rain / Wind** to recolour. **Forecast** colours cities by the trained models' next-day maximum temperature. Click a city for a popup with observed values, the station used (and its distance from the city centre) and the model forecast, and to focus the charts below.
2. **Alerts & watch list (top right).** Threshold crossings computed from the same station data. Pick *Latest day* (alert + watch levels) or a 14/30/90-day window; click an alert to focus that city on the map and chart.
3. **Charts.** Daily series and monthly heatmap for ECMWF estimates vs DWD stations, with CSV export.
4. **Model performance.** Holdout MAE and tolerance hit rate for the four deployed models.

**Internet needs.** The dashboard needs the internet for two things only: the Leaflet library (loaded from unpkg, pinned to 1.9.4) and map tiles (Esri / CARTO). If Leaflet is unreachable the map shows an offline schematic Germany outline, still coloured with the same real data. If satellite tiles fail it switches to the CARTO dark map; if those fail too it switches to the schematic outline. The caption under the map always names the basemap in use. If the station-data endpoint fails, the map and alerts panel show the API error instead of coloured markers. Everything else works offline. Pre-warm the tiles by opening the dashboard once before presenting, and do not rely on conference Wi-Fi without a fallback.

**What the numbers are.** Map colours and alerts are *observed* DWD station values from a bundled snapshot (through 2026-10-16; 2026 values provisional), not live data. Alert/watch levels are illustrative screening rules (alert: heat ≥ 30 °C, frost ≤ 0 °C, rain ≥ 20 mm/day, wind ≥ 60 km/h; watch: 25 / 3 / 10 / 45), not official DWD warnings. The forecast layer is a model output on ECMWF grid data for the day after the snapshot (2026-10-17); it is not live and not station data. Run `python scripts/refresh_dwd_recent.py` (needs internet) to refresh the station snapshot and restart uvicorn.

New endpoints: `GET /api/v1/weather/map[?date=YYYY-MM-DD]` (observed conditions + risk per city), `GET /api/v1/weather/alerts?days=1..365` (now includes frost, severity-sorted, city coordinates), `GET /api/v1/forecast/cities` (per-city next-day model forecast).

## Run on LinuxONE (native Linux)

The dashboard and API are served together at **http://localhost:8000**. The project uses the bundled 2024 dataset and fitted model artifacts; local forecasts and quality scans do not require paid APIs or internet access. The seasonal outlook makes an optional request to Open-Meteo and reports a clear unavailable state if that provider cannot be reached.

Use a Python 3.13 environment with the bundled models' scikit-learn version (1.8.0):

```bash
python3.13 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m uvicorn climate_guard.api:app --host 0.0.0.0 --port 8000
```

Open `http://<linuxone-host>:8000`. For access from another machine, allow TCP port 8000 in the host firewall and use a trusted network or reverse proxy with TLS. The API itself has no user authentication; do not expose it directly to the public internet. Keep `data/`, `artifacts/`, and `frontend/` alongside the `climate_guard/` package. Do not retrain on startup.

If a compatible scikit-learn 1.8.0 build is unavailable for the chosen LinuxONE distribution, install its compiler/build prerequisites and build/install that version natively, or retrain the bundled pipeline on the target environment. The inference code intentionally rejects model/runtime scikit-learn version mismatches. Never load untrusted `.joblib` files.

### Container option

On a host with Docker or Podman Compose, build and run from this directory:

```bash
docker compose up --build
```

The image is built for the host architecture, including `s390x` where the base image and Python dependencies can be installed. The Docker build installs compiler prerequisites so packages can build from source when a matching wheel is unavailable. First-time builds may take longer on LinuxONE.

### Windows PowerShell

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn climate_guard.api:app --reload
```

Open **http://127.0.0.1:8000** for the dashboard or **http://127.0.0.1:8000/docs** for the API.

### Dashboard features

- Next-day forecasts from the bundled historical data or an uploaded hourly JSON batch.
- Sensor-quality scan and uploaded-batch scan.
- Model holdout metrics and original-dataset coverage.
- Daily historical weather explorer across nine cities, 2024–2026 YTD, using a separately sourced ECMWF IFS archive.
- Optional ECMWF SEAS5 monthly outlook through Open-Meteo (no paid API key required).
- Responsive interface with no frontend build step, no external fonts, and one external library (Leaflet via unpkg, with an offline fallback map). Markers are the nine city-centre points; observed values come from the nearest bundled DWD stations listed in the popup.

## Measured results: 2024 chronological retrospective test

| Next-day target | Selected algorithm | Accuracy within tolerance | MAE | Previous-day baseline accuracy |
|---|---|---:|---:|---:|
| Low temperature | Ridge (22 selected prior-day features) | **72.46%** within ±2°C | **1.53°C** | 69.57% |
| High temperature | Previous-day persistence | **56.52%** within ±2°C | **2.39°C** | 56.52% |
| Low relative humidity | Two-previous-day mean | **38.89%** within ±5 RH points | **8.92 points** | 38.89% |
| High relative humidity | Random Forest | **73.61%** within ±5 RH points | **4.10 points** | 75.00% |

These are *tolerance-hit rates*, not conventional regression "accuracy". When the tolerance is relaxed to ±3°C and ±15 RH points, the hit rates are **88.41%, 72.46%, 83.33%, and 100.00%**, respectively; they are **not equivalent to the strict figures**. Full MAE, RMSE, R², baseline comparison, and individual holdout rows are in `reports/model_metrics.csv` and `reports/holdout_predictions.csv`.

**Scientific caveat:** The last 20% of 2024 was chronologically excluded from each run's training and automatic candidate selection, but the same period was already examined in V3/V4 iterations. V5 improvements are therefore **exploratory**, not a new independent test or proof of 2026 performance. A new future year is needed for reliable external validation. Forecasting a current day also requires current observed weather; the bundled 2024 data does not constitute live 2026 input.

## Improvements beyond V4

- Explored Ridge regularization, RF, Extra Trees, HistGradientBoosting, GradientBoosting, XGBoost, LightGBM, CatBoost, and persistence variants in time-forward internal validation.
- Experimented with compact 22-feature sets, original 33+ features, and 200+ engineered lagged hourly variables (dewpoint, precipitation, daily trends, hour of day, etc.). **Never** use readings from the day being forecast; source/provider columns and precomputed `daily_*` labels are excluded.
- Only the low-temperature candidate demonstrated a reproducible improvement on the retrospective final period, so it is the only upgraded deployed estimator. High-temperature and low-humidity models retain persistence-based methods to avoid deploying demonstrably weaker ML.
- Model scripts remain independent: `climate_guard/models/{low_temperature,high_temperature,low_humidity,high_humidity}.py`. They save their own model bundles + JSON evaluations.
- `experiment_search.py` is an **optional research script** to reproduce the wider candidate exploration. To run it, separately install `lightgbm`, `xgboost`, `catboost`. It is **not** needed for the production API, model training, or CSV exporter. It records an exploratory final-period score but does not select by that score.
- `climate_guard/advanced_features.py` holds exploratory leakage-safe feature engineering; production deploys only features needed by its selected models.

## API routes

| Method and path | Purpose |
|---|---|
| `GET /api/v1/health` | Verify assets and data |
| `GET /api/v1/models/metrics` | Show saved backtest figures for all four models |
| `GET /api/v1/dataset/summary` | Inspect original 2024 CSV rows and gaps |
| `GET /api/v1/weather/history/summary` | Historical archive provenance, locations and years |
| `GET /api/v1/weather/history/daily?location=Berlin&year=2026&metric=temperature_2m` | Daily aggregated regional history |
| `GET /api/v1/forecast/next-day` | Demo next-day forecast after the bundled CSV (2025-01-01) |
| `POST /api/v1/forecast/next-day` | Supply at least 8 days of real recent hourly observations and forecast the following day |
| `GET /api/v1/quality/scan` | Missing data, stuck readings, spikes, suspicious source changes, Isolation Forest |
| `POST /api/v1/quality/scan` | Run same checks against uploaded JSON sensor observations |
| `GET /api/v1/outlook/next-month` | Live model-based seasonal warm/dry outlook for Germany |
| `GET /api/v1/outlook/locations` | Coordinates of nine seasonal outlook sampling points (not dataset station coordinates) |
| `GET /api/v1/outlook/month?year=2026&month=11` | Live future-month outlook |
| `GET /docs` | OpenAPI Swagger interface |

**Seasonal outlook limitations:** Monthly model is an external ECMWF SEAS5 forecast accessed through Open-Meteo (future-month only), not a model trained on the single local 2024 year. It takes model monthly anomalies at nine locations as a rough German spatial proxy. It may be unavailable if the remote provider is unreachable; the code returns HTTP 503 rather than fabricating weather. A multi-year historical upload is **not required**, but it does not make the single-year dataset a valid long-term climate-normal baseline. No station coordinates or adjacent station observations are provided, so neighboring-station verification is explicitly marked unavailable.

## Generate your Excel-friendly reports

```powershell
python export_model_metrics.py
```

The CSVs will be in `reports/`. Regenerate trained artifacts after your own dataset/model changes with `python -m climate_guard.train_all --data data/meteostat_2024.csv --output artifacts`.

## Tests

```powershell
python -m pytest -q
```

Check all `artifacts/low_temperature.json`, `high_temperature.json`, `low_humidity.json`, and `high_humidity.json` for target-wise details. Temperature has **432 intentionally blank readings in six 72-hour blocks**, so any incomplete 24-hour days are excluded from its daily training labels. Model feature sets never use same-day target observations.

## 2024–2026 regional weather archive

The dashboard includes a separate hourly archive for the nine sample cities from **2024-01-01 through 2026-10-16**. It is sourced from the Open-Meteo Historical Weather API using the ECMWF IFS model and is displayed as gridded model estimates, **not station observations**. The archive powers the daily history explorer; it is not merged into the original 2024 station-like CSV or used to retrain the supplied models. The original CSV has no verified station coordinates, so these are distinct datasets.

The archive is bundled locally, so browsing its history does not call a paid API or require network access. Open-Meteo data are licensed under CC BY 4.0 and require attribution. Its free API terms limit use to non-commercial purposes; suitable for educational/datathon use, not a commercial deployment without a separate license. See [Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api) and [Open-Meteo terms](https://open-meteo.com/en/terms). Provenance, coordinates, units, retrieval date, and model are in `data/reanalysis_hourly_2024_2026.metadata.json`.

The dashboard aggregates hourly values into daily mean temperature, humidity, wind and cloud cover, daily precipitation and sunshine totals, and daily maximum gusts. 2026 is year to date through October 16. The historical explorer does not turn this archive into a live forecast; the supplied next-day models still use the original 2024 data.


## Reference-style dashboard refresh

The frontend now uses a workspace-style analytics layout with a compact sidebar, weather-variable/year/city controls, selectable Germany city markers, daily comparison lines, and a monthly deviation heatmap. The heatmap compares each month with that city’s mean for the selected year; it is not a long-term climate normal. Model scores use the retrained pooled-city archive artifacts and the holdout dates saved with those artifacts. The next-day demo is not a live forecast and still requires recent observations for a current prediction.

Current retrained holdout range: **2026-03-28 through 2026-10-16**, evaluated on pooled city-days from nine ECMWF IFS grid locations. Values in the model panel are MAE and strict tolerance hit rate. Gridded estimates are not station observations.
# DWD station dashboard extension (2024–2026)

The redesigned dashboard now has three chart source modes: ECMWF gridded estimates, DWD station observations, and a selected-city comparison overlay. Use the date filters, choose a city on the map or city selector, and download the visible series as CSV. The heatmap follows the chosen source and selected date range.

## Station observations and limitations

`data/dwd_station_observations_2024_2026.csv` bundles hourly observations from nine selected DWD stations, from 2024-01-01 through 2026-10-16. Historical `hist` archives are used through 2025-12-31; 2026 values come from DWD `recent/akt` files and are provisional because DWD quality control can revise them. Station IDs, coordinates, city-center distances, missing-value counts, source URLs and attribution are in `data/dwd_station_observations.metadata.json`. A city may use different nearby stations for temperature, precipitation and wind. A DWD station is not necessarily located at the city-center marker.

The DWD data are provided by the DWD Climate Data Center under CC BY 4.0. The ECMWF archive is an Open-Meteo historical-weather dataset with CC BY 4.0 attribution. These are separate sources and should remain labeled as such. The dashboard's heat, rain and wind thresholds are illustrative screening rules, not official DWD warnings.

## Start on LinuxONE

From the extracted project directory, use the existing virtual environment if it already has the app dependencies:

```bash
cd ~/ClimateGuard_AI_Germany
source .venv/bin/activate
python -m uvicorn climate_guard.api:app --host 0.0.0.0 --port 8000
```

Then open `http://148.100.109.151:8000/` in a browser, replacing the address if the VM public IP changed. If the browser times out while the API reports that it is running, allow inbound TCP 8000 for the VM in the LinuxONE cloud firewall/security group. For a private connection instead, run `ssh -i <key.pem> -L 8000:localhost:8000 linux1@<public-ip>` from Windows and open `http://localhost:8000/`.

## Refresh DWD recent data

The bundled archive is a dated snapshot. To replace the provisional 2026+ rows with the latest DWD recent files, run from the project directory while the VM has internet access:

```bash
source .venv/bin/activate
python scripts/refresh_dwd_recent.py
```

Restart Uvicorn after the refresh so the API reloads its cached CSV. The script preserves quality-checked 2024–2025 records and refreshes only 2026 onward. It downloads only the DWD station files used by this project; no paid API is required.

## Compare model outputs with stations

The in-dashboard station comparison quantifies daily differences between ECMWF estimates and DWD observations. To separately evaluate the trained ECMWF-based daily models against DWD station measurements on a later date range, run:

```bash
source .venv/bin/activate
python scripts/validate_models_vs_dwd.py
```

This fits/selects models using ECMWF targets only before 2026-03-28 and compares predictions for later days against station labels. It writes per-target tables and `reports/dwd_model_validation.json`. This is a cross-source diagnostic, not an official forecast-skill claim: predictors and training labels are gridded ECMWF values, while evaluation labels are station measurements. The script requires the installed project Python dependencies and enough DWD hourly coverage (at least 18 values per city-day by default).

## Sources

- [DWD hourly air-temperature and humidity dataset description](https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/air_temperature/DESCRIPTION_obsgermany_climate_hourly_air_temperature_en.pdf)
- [DWD hourly wind dataset description](https://opendata.dwd.de/climate_environment/CDC/observations_germany/climate/hourly/wind/DESCRIPTION_obsgermany_climate_hourly_wind_en.pdf)
- [DWD terms of use (CC BY 4.0)](https://opendata.dwd.de/climate_environment/CDC/Nutzungsbedingungen_German.pdf)
- [Open-Meteo historical weather API documentation](https://open-meteo.com/en/docs/historical-weather-api)
