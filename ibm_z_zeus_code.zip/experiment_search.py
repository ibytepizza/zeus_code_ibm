"""CV exploration confined to initial 80% of 2024; final test never used for ranking."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import warnings,time,json
warnings.filterwarnings('ignore',category=UserWarning)
warnings.filterwarnings('ignore',category=__import__('pandas').errors.PerformanceWarning)
import numpy as np,pandas as pd
from sklearn.linear_model import Ridge,ElasticNet
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import ExtraTreesRegressor,RandomForestRegressor,HistGradientBoostingRegressor,GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error
from lightgbm import LGBMRegressor
from catboost import CatBoostRegressor
from xgboost import XGBRegressor
from climate_guard.data import read_hourly,TARGETS
from climate_guard.features import daily_target, make_feature_frame
from climate_guard.advanced_features import advanced_feature_frame, target_feature_groups
from climate_guard.modelling import BASE_COLS

D=read_hourly('data/meteostat_2024.csv')
F=advanced_feature_frame(D)
oldCols=list(make_feature_frame(D).columns)

# Models tuned ONLY by rolling training CV. All training observations prior to validation dates.
def build(name):
  if name=='ridge1':return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=1))
  if name=='ridge30':return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=30))
  if name=='ridge150':return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=150))
  if name=='ridge500':return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=500))
  if name=='ridge3000':return make_pipeline(SimpleImputer(strategy='median'),StandardScaler(),Ridge(alpha=3000))
  if name=='extra':return ExtraTreesRegressor(n_estimators=120,max_depth=6,min_samples_leaf=4,max_features=.9,n_jobs=1,random_state=42)
  if name=='rf':return RandomForestRegressor(n_estimators=120,max_depth=6,min_samples_leaf=5,max_features=.8,n_jobs=1,random_state=42)
  if name=='hist':return HistGradientBoostingRegressor(max_iter=120,max_leaf_nodes=5,min_samples_leaf=18,learning_rate=.03,l2_regularization=5,early_stopping=False,random_state=42)
  if name=='lightgbm':return LGBMRegressor(n_estimators=120,num_leaves=5,max_depth=3,min_child_samples=22,learning_rate=.03,reg_lambda=10,verbosity=-1,n_jobs=1,random_state=42)
  if name=='cat':return CatBoostRegressor(iterations=160,depth=4,learning_rate=.035,l2_leaf_reg=10,verbose=False,thread_count=1,random_seed=42)
  if name=='xgb':return XGBRegressor(n_estimators=120,max_depth=2,learning_rate=.04,min_child_weight=12,subsample=.9,colsample_bytree=.8,reg_lambda=10,n_jobs=1,random_state=42)
  if name=='gb':return make_pipeline(SimpleImputer(strategy='median'),GradientBoostingRegressor(n_estimators=120,max_depth=2,min_samples_leaf=12,learning_rate=.03,loss='huber',random_state=42))
  raise Exception(name)

candidateNames=('ridge1','ridge30','ridge150','ridge500','ridge3000','extra','rf','hist','lightgbm','cat','xgb','gb')
output={}
for target in TARGETS:
  tol=2 if 'temperature' in target else 5
  E=F.join(daily_target(D,target)).iloc[7:].dropna(subset=[target]); N=len(E); split=int(N*.8)
  train=E.iloc[:split];test=E.iloc[split:]
  cv_folds=[(int(split*.48),int(split*.67)),(int(split*.67),int(split*.83)),(int(split*.83),split)]
  groups=target_feature_groups(F,target)
  groups['original']=oldCols
  bc=BASE_COLS[target]
  ranked=[]
  for grp in ('original','minimal','focus','all'):
    cols=groups[grp]
    for name in candidateNames:
      if grp=='all' and name in ('ridge1','ridge30','extra','rf','gb','hist','lightgbm','xgb','cat'):continue
      pred=[];truth=[]
      start=time.monotonic()
      for a,b in cv_folds:
        tr=train.iloc[:a]; va=train.iloc[a:b]
        md=build(name)
        md.fit(tr[cols],tr[target]); yhat=md.predict(va[cols]);pred.extend(yhat);truth.extend(va[target].values)
      pred=np.asarray(pred);truth=np.asarray(truth)
      sc=(100*np.mean(np.abs(truth-pred)<=tol),mean_absolute_error(truth,pred))
      ranked.append({'name':f'{name}/{grp}','model':name,'group':grp,'accuracy':sc[0],'mae':sc[1]})
  ranked.sort(key=lambda v:(-v['accuracy'],v['mae']))
  # select by CV accuracy plus MAE tie break; no test selection
  best=ranked[0]; md=build(best['model']); cols=groups[best['group']];md.fit(train[cols],train[target]);p=md.predict(test[cols]);
  baseline=test[bc].to_numpy(dtype=float); baseline=np.where(np.isfinite(baseline),baseline,float(train[target].median()))
  print('\n',target,' CV BEST',[(i['name'],round(i['accuracy'],1),round(i['mae'],2)) for i in ranked[:10]],flush=True)
  print('TEST selected', best['name'],round(100*np.mean(np.abs(test[target]-p)<=tol),1),'MAE',round(mean_absolute_error(test[target],p),2),
   'BASELINE',round(100*np.mean(np.abs(test[target]-baseline)<=tol),1),'MAE',round(mean_absolute_error(test[target],baseline),2),flush=True)
  output[target]={'ranked':ranked,'cv_folds':cv_folds,'holdout_selected':{'accuracy':100*np.mean(np.abs(test[target]-p)<=tol),'mae':mean_absolute_error(test[target],p)},
                  'baseline':{'accuracy':100*np.mean(np.abs(test[target]-baseline)<=tol),'mae':mean_absolute_error(test[target],baseline)}}
with open('reports/candidate_experiment.json','w') as fd:json.dump(output,fd,indent=2)
